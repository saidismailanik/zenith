package com.rtha.zenith.activities

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.app.AlertDialog
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.rtha.zenith.R
import com.rtha.zenith.network.MovieRepository
import com.rtha.zenith.services.DownloadService.Companion.EXTRA_RUNTIME
import com.rtha.zenith.subtitle.SubtitleRepository
import com.rtha.zenith.subtitle.SubtitleResult
import com.rtha.zenith.utils.StreamScraper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.rtha.zenith.models.AppDatabase

class PlayerActivity : AppCompatActivity() {

    private lateinit var playerView: PlayerView
    private lateinit var doubleTapLeft: View
    private lateinit var doubleTapRight: View
    private lateinit var tvSeekLeft: TextView
    private lateinit var tvSeekRight: TextView

    private var exoPlayer: ExoPlayer? = null
    private var currentStreamUrl: String? = null

    // Subtitle
    private val subtitleRepo = SubtitleRepository()
    // Add fields:
    private var progressSaveHandler = Handler(Looper.getMainLooper())
    private var progressSaveRunnable: Runnable? = null
    private var currentMovieData: android.os.Bundle? = null  // store movie metadata
    private val movieRepo = MovieRepository()
    private var movieImdbId: String? = null
    private var availableSubtitles: List<SubtitleResult> = emptyList()
    private var subtitlesEnabled = false  // OFF by default

    // Double tap
    private var pendingSeekLeft = 0
    private var pendingSeekRight = 0
    private val seekResetHandler = Handler(Looper.getMainLooper())
    private val resetLeftRunnable = Runnable { pendingSeekLeft = 0 }
    private val resetRightRunnable = Runnable { pendingSeekRight = 0 }

    companion object {

        const val EXTRA_OVERVIEW      = "overview"
        const val EXTRA_BACKDROP_PATH = "backdrop_path"
        const val EXTRA_VOTE_AVERAGE  = "vote_average"
        const val EXTRA_RELEASE_DATE_STR = "release_date_str"
        const val EXTRA_STREAM_URL = "stream_url"
        const val EXTRA_MOVIE_TITLE = "movie_title"
        const val EXTRA_MOVIE_ID = "movie_id"
        const val EXTRA_RUNTIME = "runtime"
        const val SEEK_INCREMENT_MS = 10_000L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)

        setContentView(R.layout.activity_player)
        hideSystemUI()

        playerView = findViewById(R.id.playerView)
        doubleTapLeft = findViewById(R.id.doubleTapLeft)
        doubleTapRight = findViewById(R.id.doubleTapRight)
        tvSeekLeft = findViewById(R.id.tvSeekLeft)
        tvSeekRight = findViewById(R.id.tvSeekRight)

        findViewById<ImageButton>(R.id.btnClosePlayer).setOnClickListener { finish() }

        findViewById<ImageButton>(R.id.btnSubtitles).setOnClickListener {
            val movieId = intent.getIntExtra(EXTRA_MOVIE_ID, -1)
            showSubtitleMenu(movieId)
        }

        setupDoubleTap()

        val streamUrl = intent.getStringExtra(EXTRA_STREAM_URL)
        val movieId = intent.getIntExtra(EXTRA_MOVIE_ID, -1)

        when {
            streamUrl != null -> {
                initPlayer(streamUrl)
                if (movieId != -1) loadSubtitlesAuto(movieId)
            }
            movieId != -1 -> {
                StreamScraper.resolve(this, movieId) { url ->
                    if (url != null) {
                        initPlayer(url)
                        loadSubtitlesAuto(movieId)
                    } else {
                        Toast.makeText(this, "Stream not found", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                }
            }
            else -> finish()
        }
    }

    // ─── Subtitle: Auto fetch (no load, no toast) ─────────────────────────────


    // ─── Watch Progress ───────────────────────────────────────────────────────────

    private fun startSavingProgress() {
        val movieId = intent.getIntExtra(EXTRA_MOVIE_ID, -1)
        if (movieId == -1) return

        progressSaveRunnable = object : Runnable {
            override fun run() {
                saveProgress()
                progressSaveHandler.postDelayed(this, 5_000L)  // every 5 seconds
            }
        }
        progressSaveHandler.postDelayed(progressSaveRunnable!!, 5_000L)
    }

    private fun saveProgress() {
        val player  = exoPlayer ?: return
        val movieId = intent.getIntExtra(EXTRA_MOVIE_ID, -1)
        if (movieId == -1) return

        val position = player.currentPosition
        val duration = player.duration.takeIf { it > 0 } ?: return
        val streamUrl = currentStreamUrl ?: return

        // Don't save if less than 2% or more than 95% watched (effectively finished)
        val percent = position.toFloat() / duration
        if (percent < 0.02f || percent > 0.95f) {
            if (percent > 0.95f) {
                // Movie finished — remove from continue watching
                CoroutineScope(Dispatchers.IO).launch {
                    AppDatabase.getInstance(this@PlayerActivity)
                        .watchProgressDao().delete(movieId)
                }
            }
            return
        }

        val entity = com.rtha.zenith.models.WatchProgressEntity(
            movieId     = movieId,
            title       = intent.getStringExtra(EXTRA_MOVIE_TITLE) ?: "",
            posterPath  = intent.getStringExtra("poster_path"),
            backdropPath = intent.getStringExtra(EXTRA_BACKDROP_PATH),
            voteAverage = intent.getDoubleExtra(EXTRA_VOTE_AVERAGE, 0.0),
            releaseDate = intent.getStringExtra(EXTRA_RELEASE_DATE_STR) ?: "",
            overview    = intent.getStringExtra(EXTRA_OVERVIEW) ?: "",
            runtime     = intent.getIntExtra(EXTRA_RUNTIME, -1).takeIf { it != -1 },
            streamUrl   = streamUrl,
            positionMs  = position,
            durationMs  = duration
        )

        CoroutineScope(Dispatchers.IO).launch {
            AppDatabase.getInstance(this@PlayerActivity)
                .watchProgressDao().save(entity)
        }
    }

    private fun stopSavingProgress() {
        progressSaveRunnable?.let { progressSaveHandler.removeCallbacks(it) }
        progressSaveRunnable = null
        saveProgress()  // final save on exit
    }

    private fun loadSubtitlesAuto(movieId: Int) {
        CoroutineScope(Dispatchers.Main).launch {
            movieImdbId = withContext(Dispatchers.IO) { movieRepo.getImdbId(movieId) }
            availableSubtitles = subtitleRepo.fetchSubtitles(movieId, movieImdbId)
            Log.d("SUBTITLE", "Fetched ${availableSubtitles.size} subtitle options")
        }
    }

    // ─── Subtitle: YouTube-style bottom sheet menu ────────────────────────────

    private fun showSubtitleMenu(movieId: Int) {
        if (availableSubtitles.isEmpty()) {
            Toast.makeText(this, "No subtitles available", Toast.LENGTH_SHORT).show()
            return
        }

        val items = mutableListOf<Pair<String, (() -> Unit)>>()
        items.add(Pair("Off") { clearSubtitles() })
        availableSubtitles.forEach { sub ->
            val label = "${sub.language.replaceFirstChar { it.uppercase() }} · ${sub.source}"
            items.add(Pair(label) { loadSubtitleFromUrl(sub.url, movieId) })
        }

        val dialogView = layoutInflater.inflate(R.layout.dialog_subtitle_picker, null)
        val listView = dialogView.findViewById<android.widget.ListView>(R.id.subtitleList)

        val dialog = AlertDialog.Builder(this, R.style.SubtitleDialogTheme)
            .setView(dialogView)
            .create()

        val adapter = SubtitleMenuAdapter(
            this,
            layoutInflater,
            items.map { it.first },
            subtitlesEnabled
        )
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, position, _ ->
            items[position].second.invoke()
            dialog.dismiss()
        }

        dialog.show()
        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setGravity(android.view.Gravity.BOTTOM)
            setLayout(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            )
            attributes = attributes?.also { it.y = 0 }
        }
    }

    // ─── Subtitle: Load from URL ──────────────────────────────────────────────

    private fun loadSubtitleFromUrl(url: String, movieId: Int) {
        CoroutineScope(Dispatchers.Main).launch {
            Toast.makeText(this@PlayerActivity, "Loading subtitle…", Toast.LENGTH_SHORT).show()
            val file = withContext(Dispatchers.IO) {
                subtitleRepo.downloadSubtitleToCache(this@PlayerActivity, url, movieId)
            }
            if (file != null) {
                subtitlesEnabled = true
                loadSubtitleFile(Uri.fromFile(file))
            } else {
                Toast.makeText(this@PlayerActivity, "Failed to download subtitle", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ─── Subtitle: Attach to ExoPlayer ───────────────────────────────────────

    private fun loadSubtitleFile(uri: Uri) {
        Log.d("SUBTITLE", "loadSubtitleFile called with URI: $uri")
        Log.d("SUBTITLE", "URI scheme: ${uri.scheme}")

        val player = exoPlayer ?: run {
            Log.e("SUBTITLE", "ExoPlayer is null")
            return
        }

        val contentUri = if (uri.scheme == "file") {
            try {
                val file = java.io.File(uri.path!!)
                Log.d("SUBTITLE", "File exists: ${file.exists()}, size: ${file.length()}")
                val result = androidx.core.content.FileProvider.getUriForFile(
                    this,
                    "${packageName}.fileprovider",
                    file
                )
                Log.d("SUBTITLE", "FileProvider URI: $result")
                result
            } catch (e: Exception) {
                Log.e("SUBTITLE", "FileProvider conversion failed: ${e.message}", e)
                Toast.makeText(this, "Failed to load subtitle", Toast.LENGTH_SHORT).show()
                return
            }
        } else {
            Log.d("SUBTITLE", "URI is already content:// — using as-is")
            uri
        }

        try {
            grantUriPermission(
                packageName,
                contentUri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (e: Exception) {
            Log.e("SUBTITLE", "grantUriPermission failed: ${e.message}", e)
        }

        val mimeType = when {
            uri.toString().endsWith(".vtt", ignoreCase = true) -> {
                Log.d("SUBTITLE", "MIME: VTT")
                MimeTypes.TEXT_VTT
            }
            else -> {
                Log.d("SUBTITLE", "MIME: SRT")
                MimeTypes.APPLICATION_SUBRIP
            }
        }

        val currentPosition = player.currentPosition
        val mediaItem = player.currentMediaItem ?: run {
            Log.e("SUBTITLE", "currentMediaItem is null")
            return
        }

        try {
            val subtitleConfig = MediaItem.SubtitleConfiguration.Builder(contentUri)
                .setMimeType(mimeType)
                .setLanguage("en")
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()

            val newMediaItem = mediaItem.buildUpon()
                .setSubtitleConfigurations(listOf(subtitleConfig))
                .build()

            player.setMediaItem(newMediaItem, currentPosition)
            player.prepare()
            player.play()
            Log.d("SUBTITLE", "Subtitle attached successfully")
            Toast.makeText(this, "Subtitles loaded ✓", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Log.e("SUBTITLE", "Failed to attach subtitle: ${e.message}", e)
            Toast.makeText(this, "Failed to load subtitle", Toast.LENGTH_SHORT).show()
        }
    }

    // ─── Subtitle: Clear ──────────────────────────────────────────────────────

    private fun clearSubtitles() {
        subtitlesEnabled = false
        val player = exoPlayer ?: return
        val currentPosition = player.currentPosition
        val mediaItem = player.currentMediaItem ?: return
        val newMediaItem = mediaItem.buildUpon()
            .setSubtitleConfigurations(emptyList())
            .build()
        player.setMediaItem(newMediaItem, currentPosition)
        player.prepare()
        player.play()
    }

    // ─── Subtitle: Adapter ────────────────────────────────────────────────────

    inner class SubtitleMenuAdapter(
        context: android.content.Context,
        private val inflater: android.view.LayoutInflater,
        private val labels: List<String>,
        private val subtitlesEnabled: Boolean
    ) : android.widget.ArrayAdapter<String>(context, 0, labels) {

        override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
            val view = convertView ?: inflater.inflate(R.layout.item_subtitle_option, parent, false)
            val tvCheck = view.findViewById<TextView>(R.id.tvCheck)
            val tvLabel = view.findViewById<TextView>(R.id.tvLabel)

            tvLabel.text = labels[position]

            val isActive = when {
                position == 0 && !subtitlesEnabled -> true
                position > 0 && subtitlesEnabled -> false
                else -> false
            }
            tvCheck.visibility = if (isActive) View.VISIBLE else View.INVISIBLE
            tvLabel.alpha = if (position == 0) 0.6f else 1.0f

            return view
        }
    }

    // ─── Double Tap Setup ─────────────────────────────────────────────────────

    private fun setupDoubleTap() {
        var leftDoubleTapped = false
        var rightDoubleTapped = false

        val leftGesture = GestureDetector(this,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onDoubleTap(e: MotionEvent): Boolean {
                    leftDoubleTapped = true
                    seekBackward()
                    return true
                }
            })

        val rightGesture = GestureDetector(this,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onDoubleTap(e: MotionEvent): Boolean {
                    rightDoubleTapped = true
                    seekForward()
                    return true
                }
            })

        doubleTapLeft.setOnTouchListener { _, event ->
            leftGesture.onTouchEvent(event)
            when (event.action) {
                MotionEvent.ACTION_DOWN -> leftDoubleTapped = false
                MotionEvent.ACTION_UP -> {
                    if (!leftDoubleTapped) {
                        val down = MotionEvent.obtain(event).apply { action = MotionEvent.ACTION_DOWN }
                        playerView.dispatchTouchEvent(down)
                        playerView.dispatchTouchEvent(event)
                        down.recycle()
                    }
                    leftDoubleTapped = false
                }
            }
            true
        }

        doubleTapRight.setOnTouchListener { _, event ->
            rightGesture.onTouchEvent(event)
            when (event.action) {
                MotionEvent.ACTION_DOWN -> rightDoubleTapped = false
                MotionEvent.ACTION_UP -> {
                    if (!rightDoubleTapped) {
                        val down = MotionEvent.obtain(event).apply { action = MotionEvent.ACTION_DOWN }
                        playerView.dispatchTouchEvent(down)
                        playerView.dispatchTouchEvent(event)
                        down.recycle()
                    }
                    rightDoubleTapped = false
                }
            }
            true
        }
    }

    private fun seekForward() {
        val player = exoPlayer ?: return
        pendingSeekRight += 10
        seekResetHandler.removeCallbacks(resetRightRunnable)
        seekResetHandler.postDelayed(resetRightRunnable, 1000)
        player.seekTo((player.currentPosition + SEEK_INCREMENT_MS).coerceAtMost(player.duration))
        tvSeekRight.text = "▶▶ ${pendingSeekRight}s"
        showSeekOverlay(tvSeekRight)
        playerView.hideController()
    }

    private fun seekBackward() {
        val player = exoPlayer ?: return
        pendingSeekLeft += 10
        seekResetHandler.removeCallbacks(resetLeftRunnable)
        seekResetHandler.postDelayed(resetLeftRunnable, 1000)
        player.seekTo((player.currentPosition - SEEK_INCREMENT_MS).coerceAtLeast(0L))
        tvSeekLeft.text = "◀◀ ${pendingSeekLeft}s"
        showSeekOverlay(tvSeekLeft)
        playerView.hideController()
    }

    private fun showSeekOverlay(view: TextView) {
        view.clearAnimation()
        view.alpha = 1f
        view.visibility = View.VISIBLE
        view.animate()
            .setStartDelay(600)
            .setDuration(400)
            .alpha(0f)
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    view.visibility = View.GONE
                    view.alpha = 1f
                }
            })
    }

    // ─── Player ───────────────────────────────────────────────────────────────

    private fun initPlayer(url: String) {
        currentStreamUrl = url
        exoPlayer = ExoPlayer.Builder(this).build().also { player ->
            playerView.player = player
            playerView.useController = true
            player.setMediaItem(MediaItem.fromUri(Uri.parse(url)))
            player.prepare()
            player.playWhenReady = true

            startSavingProgress()

            val seekPosition = intent.getLongExtra("seek_position", 0L)
            if (seekPosition > 0L) player.seekTo(seekPosition)
        }

        playerView.postDelayed({
            playerView.findViewById<ImageButton>(R.id.btnClosePlayer)
                ?.setOnClickListener { finish() }
        }, 500)
    }

    // ─── System UI ────────────────────────────────────────────────────────────

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUI()
    }

    private fun hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    )
        }
    }

    // ─── Lifecycle ────────────────────────────────────────────────────────────

    override fun onPause() {
        saveProgress()
        exoPlayer?.pause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        exoPlayer?.play()
        hideSystemUI()
    }

    override fun onDestroy() {
        stopSavingProgress()
        seekResetHandler.removeCallbacksAndMessages(null)
        exoPlayer?.release()
        exoPlayer = null
        super.onDestroy()
    }

    override fun onBackPressed() {
        exoPlayer?.stop()
        super.onBackPressed()
    }
}