package com.rtha.zenith.subtitle

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class SubtitleResult(
    val name: String,
    val language: String,
    val url: String,     // direct .srt or .vtt download URL
    val source: String   // "SubDL", "YIFY", "Local"
)

class SubtitleRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    // ── 1. SubDL (primary) ────────────────────────────────────────────────────
    // Free API, no auth for basic use, returns direct CDN links
    private val SUBDL_API_KEY = "subdl_7FUyPpNwLr458p-5p7w7PNrm81aMlqcvMir0FDzVRTQ" // paste your key

    suspend fun fetchFromSubDL(
        imdbId: String?,
        tmdbId: Int? = null,
        language: String = "en"
    ): List<SubtitleResult> = withContext(Dispatchers.IO) {
        try {
            val query = when {
                imdbId != null -> "imdb_id=$imdbId"
                tmdbId != null -> "tmdb_id=$tmdbId"
                else -> return@withContext emptyList()
            }
            val url = "https://api.subdl.com/api/v1/subtitles?api_key=$SUBDL_API_KEY&$query&languages=$language&subs_per_page=5&type=movie"
            val request = Request.Builder().url(url)
                .header("User-Agent", "MovieStreamApp/1.0")
                .build()
            val responseBody = client.newCall(request).execute().use { it.body?.string() }
            Log.d("SUBTITLE", "SubDL raw response: $responseBody")

            if (responseBody.isNullOrBlank()) return@withContext emptyList()

            val json = JSONObject(responseBody)
            if (!json.optBoolean("status", false)) {
                Log.w("SUBTITLE", "SubDL status=false: $responseBody")
                return@withContext emptyList()
            }

            val results = json.optJSONArray("subtitles") ?: return@withContext emptyList()
            buildList {
                for (i in 0 until results.length()) {
                    val sub = results.getJSONObject(i)
                    val dlUrl = "https://dl.subdl.com${sub.optString("url")}"
                    add(SubtitleResult(
                        name = sub.optString("release_name", "Subtitle ${i + 1}"),
                        language = sub.optString("language", language),
                        url = dlUrl,
                        source = "SubDL"
                    ))
                }
            }
        } catch (e: Exception) {
            Log.w("SubtitleRepo", "SubDL failed: ${e.message}")
            emptyList()
        }
    }
    // ── 2. YIFY Subtitles (fallback) ─────────────────────────────────────────
    // No auth, no rate limit, works by IMDB ID
    suspend fun fetchFromYIFY(
        imdbId: String,          // e.g. "tt1234567"
        language: String = "english"
    ): List<SubtitleResult> = withContext(Dispatchers.IO) {
        try {
            val url = "https://yifysubtitles.ch/movie-imdb/$imdbId"
            val request = Request.Builder().url(url)
                .header("User-Agent", "Mozilla/5.0")
                .build()
            val html = client.newCall(request).execute().use { it.body?.string() } ?: return@withContext emptyList()

            // Parse subtitle rows: <tr> blocks containing language and /subtitles/ link
            val rowPattern = Regex("""<tr[^>]*>.*?</tr>""", RegexOption.DOT_MATCHES_ALL)
            val langPattern = Regex("""class="sub-lang"[^>]*>([^<]+)<""")
            val linkPattern = Regex("""href="(/subtitles/[^"]+)"""")

            buildList {
                rowPattern.findAll(html).forEach { row ->
                    val lang = langPattern.find(row.value)?.groupValues?.get(1)?.trim() ?: return@forEach
                    if (!lang.lowercase().contains(language.lowercase())) return@forEach
                    val path = linkPattern.find(row.value)?.groupValues?.get(1) ?: return@forEach
                    // Construct direct .srt download
                    val srtUrl = "https://yifysubtitles.ch$path".replace("/subtitles/", "/subtitle/") + ".zip"
                    add(SubtitleResult(
                        name = "$lang subtitle",
                        language = lang,
                        url = srtUrl,
                        source = "YIFY"
                    ))
                }
            }.take(5)
        } catch (e: Exception) {
            Log.w("SubtitleRepo", "YIFY failed: ${e.message}")
            emptyList()
        }
    }

    // ── 3. Combined fetch ─────────────────────────────────────────────────────
    suspend fun fetchSubtitles(
        tmdbId: Int,
        imdbId: String? = null,
        language: String = "en"
    ): List<SubtitleResult> {
        // Try SubDL first (fastest, cleanest)
        val subDLResults = fetchFromSubDL(imdbId, tmdbId, language)
        if (subDLResults.isNotEmpty()) return subDLResults

        // Fallback to YIFY if we have IMDB ID
        if (imdbId != null) {
            val yifyResults = fetchFromYIFY(imdbId, language)
            if (yifyResults.isNotEmpty()) return yifyResults
        }

        return emptyList()
    }

    companion object {
        // Exactly these 5 languages, in priority order. Skip if not found.
        val TARGET_LANGUAGES = listOf("en", "es", "fr", "bn", "hi")

        // SubDL language codes map
        val LANGUAGE_LABELS = mapOf(
            "en" to "English",
            "es" to "Spanish",
            "fr" to "French",
            "bn" to "Bengali",
            "hi" to "Hindi"
        )
    }

    /**
     * Downloads one subtitle per language (up to 5 languages) for a movie.
     * Returns the folder path where .srt files are saved, or null if none downloaded.
     * Files are named: en.srt, es.srt, fr.srt, bn.srt, hi.srt
     */
    suspend fun downloadSubtitlesForMovie(
        context: android.content.Context,
        movieId: Int,
        imdbId: String?
    ): String? = withContext(Dispatchers.IO) {
        val subDir = java.io.File(context.getExternalFilesDir(null), "subtitles/$movieId").also { it.mkdirs() }
        var anyDownloaded = false

        for (langCode in TARGET_LANGUAGES) {
            try {
                Log.d("SUBTITLE", "Fetching subtitle for lang=$langCode, movieId=$movieId")

                // Try SubDL first
                val results = fetchFromSubDL(imdbId, movieId, langCode)
                    .ifEmpty {
                        // Fallback to YIFY only for English (YIFY only has English well-indexed)
                        if (langCode == "en" && imdbId != null) fetchFromYIFY(imdbId, "english")
                        else emptyList()
                    }

                if (results.isEmpty()) {
                    Log.d("SUBTITLE", "No subtitle found for lang=$langCode — skipping")
                    continue
                }

                val url = results.first().url
                Log.d("SUBTITLE", "Downloading $langCode subtitle from: $url")

                val downloaded = downloadToFile(url, subDir, langCode)
                if (downloaded) {
                    Log.d("SUBTITLE", "Saved $langCode.srt")
                    anyDownloaded = true
                }
            } catch (e: Exception) {
                Log.w("SUBTITLE", "Failed for lang=$langCode: ${e.message}")
                // Skip this language, continue with next
            }
        }

        if (anyDownloaded) subDir.absolutePath else null
    }

    /**
     * Downloads a subtitle URL directly into a named file (e.g. en.srt) inside destDir.
     */
    private suspend fun downloadToFile(
        url: String,
        destDir: java.io.File,
        langCode: String
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.5")
                .header("Referer", "https://yifysubtitles.ch/")
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                Log.e("SUBTITLE", "HTTP ${response.code} for $url")
                response.close()
                return@withContext false
            }

            val bytes = response.use { it.body?.bytes() } ?: return@withContext false
            if (bytes.size < 100) return@withContext false

            val isHtml = String(bytes.take(500).toByteArray()).contains("<html", ignoreCase = true)
            if (isHtml) return@withContext false

            val isZip = bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte()
            val outFile = java.io.File(destDir, "$langCode.srt")

            if (isZip || url.endsWith(".zip")) {
                val zipFile = java.io.File(destDir, "$langCode.zip")
                zipFile.writeBytes(bytes)
                var found = false
                java.util.zip.ZipInputStream(zipFile.inputStream()).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (entry.name.endsWith(".srt", ignoreCase = true) ||
                            entry.name.endsWith(".vtt", ignoreCase = true)) {
                            outFile.outputStream().use { zip.copyTo(it) }
                            found = true
                            break
                        }
                        entry = zip.nextEntry
                    }
                }
                zipFile.delete()
                return@withContext found
            } else {
                outFile.writeBytes(bytes)
                return@withContext true
            }
        } catch (e: Exception) {
            Log.e("SUBTITLE", "downloadToFile error: ${e.message}")
            false
        }
    }

    // ── Download subtitle to cache ────────────────────────────────────────────
    suspend fun downloadSubtitleToCache(
        context: android.content.Context,
        url: String,
        movieId: Int
    ): java.io.File? = withContext(Dispatchers.IO) {
        try {
            Log.d("SUBTITLE", "Downloading from: $url")

            val request = Request.Builder().url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.5")
                .header("Referer", "https://yifysubtitles.ch/")
                .build()

            val response = client.newCall(request).execute()
            Log.d("SUBTITLE", "Response code: ${response.code}, content-type: ${response.header("Content-Type")}, url: ${response.request.url}")

            if (!response.isSuccessful) {
                Log.e("SUBTITLE", "Bad response: ${response.code} for $url")
                response.close()
                return@withContext null
            }

            val bytes = response.use { it.body?.bytes() } ?: run {
                Log.e("SUBTITLE", "Response body null")
                return@withContext null
            }
            Log.d("SUBTITLE", "Downloaded ${bytes.size} bytes")

            // Check if we got HTML instead of a zip (bot protection redirect)
            if (bytes.size < 100) {
                Log.e("SUBTITLE", "Response too small (${bytes.size} bytes) — likely blocked or redirect")
                return@withContext null
            }
            val firstBytes = bytes.take(4).toByteArray()
            val isZip = firstBytes[0] == 0x50.toByte() && firstBytes[1] == 0x4B.toByte()
            val isHtml = String(bytes.take(500).toByteArray()).contains("<html", ignoreCase = true)

            if (isHtml) {
                Log.e("SUBTITLE", "Got HTML instead of file — site blocked the request")
                return@withContext null
            }

            val cacheDir = java.io.File(context.cacheDir, "subtitles").also { it.mkdirs() }

            // SubDL zips and YIFY zips both handled here
            if (isZip || url.endsWith(".zip")) {
                Log.d("SUBTITLE", "Extracting ZIP")
                val zipFile = java.io.File(cacheDir, "$movieId.zip")
                zipFile.writeBytes(bytes)
                java.util.zip.ZipInputStream(zipFile.inputStream()).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        Log.d("SUBTITLE", "ZIP entry: ${entry.name}")
                        if (entry.name.endsWith(".srt", ignoreCase = true) ||
                            entry.name.endsWith(".vtt", ignoreCase = true)) {
                            val ext = if (entry.name.endsWith(".vtt", ignoreCase = true)) "vtt" else "srt"
                            val out = java.io.File(cacheDir, "$movieId.$ext")
                            out.outputStream().use { zip.copyTo(it) }
                            zipFile.delete()
                            Log.d("SUBTITLE", "Extracted to: ${out.absolutePath}, size: ${out.length()} bytes")
                            return@withContext out
                        }
                        entry = zip.nextEntry
                    }
                }
                Log.e("SUBTITLE", "No .srt/.vtt found inside ZIP")
                zipFile.delete()
                return@withContext null
            } else {
                val ext = if (url.contains(".vtt", ignoreCase = true)) "vtt" else "srt"
                val file = java.io.File(cacheDir, "$movieId.$ext")
                file.writeBytes(bytes)
                Log.d("SUBTITLE", "Saved to: ${file.absolutePath}, size: ${file.length()} bytes")
                return@withContext file
            }
        } catch (e: Exception) {
            Log.e("SUBTITLE", "Download exception: ${e.message}", e)
            null
        }
    }
}