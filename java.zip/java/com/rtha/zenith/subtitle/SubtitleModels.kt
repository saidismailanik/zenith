package com.rtha.zenith.subtitle

import com.google.gson.annotations.SerializedName

data class OpenSubtitlesResponse(
    @SerializedName("data") val data: List<SubtitleData> = emptyList()
)

data class SubtitleData(
    @SerializedName("id") val id: String = "",
    @SerializedName("attributes") val attributes: SubtitleAttributes
)

data class SubtitleAttributes(
    @SerializedName("language") val language: String = "",
    @SerializedName("release") val release: String = "",
    @SerializedName("files") val files: List<SubtitleFile> = emptyList(),
    @SerializedName("download_count") val downloadCount: Int = 0
)

data class SubtitleFile(
    @SerializedName("file_id") val fileId: Int = 0,
    @SerializedName("file_name") val fileName: String = ""
)

data class DownloadLinkResponse(
    @SerializedName("link") val link: String = ""
)

data class SubtitleTrack(
    val fileId: Int,
    val language: String,
    val languageDisplay: String,
    val releaseName: String,
    val downloadCount: Int
)

val SUBTITLE_OFF = SubtitleTrack(
    fileId = -1,
    language = "",
    languageDisplay = "Off",
    releaseName = "",
    downloadCount = 0
)