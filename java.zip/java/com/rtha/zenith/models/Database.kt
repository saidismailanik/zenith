package com.rtha.zenith.models

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ─── Watch Progress Entity ────────────────────────────────────────────────────

@Entity(tableName = "watch_progress")
data class WatchProgressEntity(
    @PrimaryKey val movieId: Int,
    val title: String,
    val posterPath: String?,
    val backdropPath: String?,
    val voteAverage: Double,
    val releaseDate: String,
    val overview: String,
    val runtime: Int?,
    val streamUrl: String,
    val positionMs: Long,
    val durationMs: Long,
    val watchedAt: Long = System.currentTimeMillis()
)

// ─── Watch Progress DAO ───────────────────────────────────────────────────────

@Dao
interface WatchProgressDao {
    @Query("SELECT * FROM watch_progress ORDER BY watchedAt DESC LIMIT 20")
    fun getAll(): Flow<List<WatchProgressEntity>>

    @Query("SELECT * FROM watch_progress WHERE movieId = :movieId LIMIT 1")
    suspend fun getByMovieId(movieId: Int): WatchProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(progress: WatchProgressEntity)

    @Query("DELETE FROM watch_progress WHERE movieId = :movieId")
    suspend fun delete(movieId: Int)

    @Query("DELETE FROM watch_progress")
    suspend fun deleteAll()
}

// ─── Offline Movie Entity ─────────────────────────────────────────────────────

@Entity(tableName = "offline_movies")
data class OfflineMovieEntity(
    @PrimaryKey val id: Int,
    val title: String,
    val posterPath: String?,
    val voteAverage: Double,
    val releaseDate: String,
    val runtime: Int?,
    val localFilePath: String,
    val downloadedAt: Long = System.currentTimeMillis()
) {
    fun toOfflineMovie() = OfflineMovie(
        id = id,
        title = title,
        posterPath = posterPath,
        voteAverage = voteAverage,
        releaseDate = releaseDate,
        runtime = runtime,
        localFilePath = localFilePath,
        downloadedAt = downloadedAt
    )
}

fun OfflineMovie.toEntity() = OfflineMovieEntity(
    id = id,
    title = title,
    posterPath = posterPath,
    voteAverage = voteAverage,
    releaseDate = releaseDate,
    runtime = runtime,
    localFilePath = localFilePath,
    downloadedAt = downloadedAt
)

// ─── DAO ──────────────────────────────────────────────────────────────────────

@Dao
interface OfflineMovieDao {
    @Query("SELECT * FROM offline_movies ORDER BY downloadedAt DESC")
    fun getAllMovies(): Flow<List<OfflineMovieEntity>>

    @Query("SELECT * FROM offline_movies ORDER BY downloadedAt DESC")
    suspend fun getAllMoviesOnce(): List<OfflineMovieEntity>

    @Query("SELECT * FROM offline_movies WHERE id = :movieId LIMIT 1")
    suspend fun getMovieById(movieId: Int): OfflineMovieEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMovie(movie: OfflineMovieEntity)

    @Delete
    suspend fun deleteMovie(movie: OfflineMovieEntity)

    @Query("DELETE FROM offline_movies WHERE id = :movieId")
    suspend fun deleteMovieById(movieId: Int)

    @Query("SELECT EXISTS(SELECT 1 FROM offline_movies WHERE id = :movieId)")
    suspend fun isMovieDownloaded(movieId: Int): Boolean

    @Query("SELECT id FROM offline_movies")
    suspend fun getAllDownloadedIds(): List<Int>
}

// ─── Room Database ────────────────────────────────────────────────────────────

@Database(
    entities = [OfflineMovieEntity::class, WatchProgressEntity::class],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun offlineMovieDao(): OfflineMovieDao
    abstract fun watchProgressDao(): WatchProgressDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        // 1→2: added subtitleDir (may or may not exist on device)
        private val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(database: androidx.sqlite.db.SupportSQLiteDatabase) {
                try {
                    database.execSQL("ALTER TABLE offline_movies ADD COLUMN subtitleDir TEXT")
                } catch (e: Exception) {
                    // Column may already exist — ignore
                }
            }
        }

        // 2→3: added watch_progress table
        private val MIGRATION_2_3 = object : androidx.room.migration.Migration(2, 3) {
            override fun migrate(database: androidx.sqlite.db.SupportSQLiteDatabase) {
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS watch_progress (
                        movieId INTEGER PRIMARY KEY NOT NULL,
                        title TEXT NOT NULL,
                        posterPath TEXT,
                        backdropPath TEXT,
                        voteAverage REAL NOT NULL,
                        releaseDate TEXT NOT NULL,
                        overview TEXT NOT NULL,
                        runtime INTEGER,
                        streamUrl TEXT NOT NULL,
                        positionMs INTEGER NOT NULL,
                        durationMs INTEGER NOT NULL,
                        watchedAt INTEGER NOT NULL
                    )
                """.trimIndent())
            }
        }

        // 3→4: drop subtitleDir column by recreating offline_movies without it
        private val MIGRATION_3_4 = object : androidx.room.migration.Migration(3, 4) {
            override fun migrate(database: androidx.sqlite.db.SupportSQLiteDatabase) {
                // Create clean table without subtitleDir
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS offline_movies_new (
                        id INTEGER PRIMARY KEY NOT NULL,
                        title TEXT NOT NULL,
                        posterPath TEXT,
                        voteAverage REAL NOT NULL,
                        releaseDate TEXT NOT NULL,
                        runtime INTEGER,
                        localFilePath TEXT NOT NULL,
                        downloadedAt INTEGER NOT NULL
                    )
                """.trimIndent())

                // Copy existing data across (subtitleDir is just dropped)
                database.execSQL("""
                    INSERT INTO offline_movies_new 
                    (id, title, posterPath, voteAverage, releaseDate, runtime, localFilePath, downloadedAt)
                    SELECT id, title, posterPath, voteAverage, releaseDate, runtime, localFilePath, downloadedAt
                    FROM offline_movies
                """.trimIndent())

                // Swap tables
                database.execSQL("DROP TABLE offline_movies")
                database.execSQL("ALTER TABLE offline_movies_new RENAME TO offline_movies")
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "moviestream.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}