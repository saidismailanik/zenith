package com.rtha.zenith.models

import com.google.gson.annotations.SerializedName

// ─── TMDB API Response Models ───────────────────────────────────────────────

data class MovieResponse(
    @SerializedName("results") val results: List<Movie> = emptyList(),
    @SerializedName("total_pages") val totalPages: Int = 0,
    @SerializedName("total_results") val totalResults: Int = 0,
    @SerializedName("page") val page: Int = 1
)

data class Movie(
    @SerializedName("id") val id: Int = 0,
    @SerializedName("title") val title: String = "",
    @SerializedName("overview") val overview: String = "",
    @SerializedName("poster_path") val posterPath: String? = null,
    @SerializedName("backdrop_path") val backdropPath: String? = null,
    @SerializedName("vote_average") val voteAverage: Double = 0.0,
    @SerializedName("release_date") val releaseDate: String = "",
    @SerializedName("genre_ids") val genreIds: List<Int> = emptyList(),
    @SerializedName("runtime") var runtime: Int? = null,
    var downloadState: DownloadState = DownloadState.NONE,
    var downloadProgress: Int = 0,
    var localFilePath: String? = null        // ← add this
) {
    val posterUrl: String get() = "https://image.tmdb.org/t/p/w500$posterPath"
    val backdropUrl: String get() = "https://image.tmdb.org/t/p/w780$backdropPath"
    val releaseYear: String get() = releaseDate.take(4)
    val ratingFormatted: String get() = String.format("%.1f", voteAverage)
    val runtimeFormatted: String get() = runtime?.let { "⏳ ${it} mins" } ?: "⏳ --"
}

data class MovieDetail(
    @SerializedName("id") val id: Int = 0,
    @SerializedName("title") val title: String = "",
    @SerializedName("overview") val overview: String = "",
    @SerializedName("poster_path") val posterPath: String? = null,
    @SerializedName("backdrop_path") val backdropPath: String? = null,
    @SerializedName("vote_average") val voteAverage: Double = 0.0,
    @SerializedName("release_date") val releaseDate: String = "",
    @SerializedName("runtime") val runtime: Int? = null,
    @SerializedName("genres") val genres: List<Genre> = emptyList()
)

data class Genre(
    @SerializedName("id") val id: Int = 0,
    @SerializedName("name") val name: String = ""
)

data class GenreResponse(
    @SerializedName("genres") val genres: List<Genre> = emptyList()
)

// ─── Credits Models ───────────────────────────────────────────────────────────

data class CreditsResponse(
    @SerializedName("cast") val cast: List<CastMember> = emptyList(),
    @SerializedName("crew") val crew: List<CrewMember> = emptyList()
)

data class CastMember(
    @SerializedName("id") val id: Int = 0,
    @SerializedName("name") val name: String = "",
    @SerializedName("character") val character: String = "",
    @SerializedName("profile_path") val profilePath: String? = null,
    @SerializedName("order") val order: Int = 0
) {
    val profileUrl: String get() = "https://image.tmdb.org/t/p/w185$profilePath"
}

data class CrewMember(
    @SerializedName("id") val id: Int = 0,
    @SerializedName("name") val name: String = "",
    @SerializedName("job") val job: String = "",
    @SerializedName("profile_path") val profilePath: String? = null
)

data class ExternalIds(
    @SerializedName("imdb_id") val imdbId: String? = null
)

// ─── Download State Enum ─────────────────────────────────────────────────────

enum class DownloadState {
    NONE,           // Not downloaded, not downloading  → "📥 Download"
    DOWNLOADING,    // In progress                      → "X%"
    COMPLETED       // Fully downloaded                 → "✓ Saved"
}

// ─── Offline Movie Model (persisted to Room) ─────────────────────────────────
data class OfflineMovie(
    val id: Int,
    val title: String,
    val posterPath: String?,
    val voteAverage: Double,
    val releaseDate: String,
    val runtime: Int?,
    val localFilePath: String,
    val subtitleDir: String? = null,         // ← new
    val downloadedAt: Long = System.currentTimeMillis()
) {
    val posterUrl: String get() = "https://image.tmdb.org/t/p/w500$posterPath"
    val releaseYear: String get() = releaseDate.take(4)
    val ratingFormatted: String get() = String.format("%.1f", voteAverage)
    val runtimeFormatted: String get() = runtime?.let { "⏳ ${it} mins" } ?: "⏳ --"

    fun toMovie(): Movie = Movie(
        id = id,
        title = title,
        posterPath = posterPath,
        voteAverage = voteAverage,
        releaseDate = releaseDate,
        runtime = runtime,
        downloadState = DownloadState.COMPLETED,
        localFilePath = localFilePath
    )
}

// ─── Genre Tab Model ─────────────────────────────────────────────────────────

data class GenreTab(
    val id: Int,
    val name: String,
    var isSelected: Boolean = false
)

// ─── Download Progress Broadcast Model ───────────────────────────────────────

