package com.rtha.zenith

import android.app.Application
import android.app.Activity
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.rtha.zenith.models.AppDatabase
import com.rtha.zenith.utils.AdOverlayHelper
import com.startapp.sdk.adsbase.Ad
import com.startapp.sdk.adsbase.StartAppAd
import com.startapp.sdk.adsbase.adlisteners.AdEventListener

class MovieApp : Application(), Application.ActivityLifecycleCallbacks {

    val database: AppDatabase by lazy { AppDatabase.Companion.getInstance(this) }

    private var currentActivity: Activity? = null
    private var startAppAd: StartAppAd? = null
    private val adSchedulerHandler = Handler(Looper.getMainLooper())
    private var warningCountdownTimer: CountDownTimer? = null

    // Test intervals (30 minute loop, 15 seconds warning)
    private val AD_INTERVAL_MS = 30 * 60 * 1000L
    private val WARNING_TIME_MS = 15 * 1000L

    override fun onCreate() {
        super.onCreate()
        database
        registerActivityLifecycleCallbacks(this)

        // Start the ad engine tracking loop
        startGlobalAdScheduler()
    }

    /**
     * Request an ad from the Start.io servers in advance so it sits in the device RAM ready to go
     */
    private fun preloadNextAd(activity: Activity) {
        if (startAppAd == null) {
            startAppAd = StartAppAd(activity)
        }

        Log.d("GlobalAdManager", "Fetching ad payload from server ahead of time...")
        startAppAd?.loadAd(StartAppAd.AdMode.AUTOMATIC, object : AdEventListener {
            override fun onReceiveAd(ad: Ad) {
                Log.d("GlobalAdManager", "SUCCESS: Interstitial ad fully downloaded and ready in memory!")
            }

            override fun onFailedToReceiveAd(ad: Ad?) {
                Log.e("GlobalAdManager", "FAILED to load ad: ${ad?.errorMessage}")
            }
        })
    }

    private fun startGlobalAdScheduler() {
        // Clear any old pending loops before making a new one
        adSchedulerHandler.removeCallbacksAndMessages(null)

        val timeBeforeWarning = AD_INTERVAL_MS - WARNING_TIME_MS
        adSchedulerHandler.postDelayed({
            startGlobalCountdown()
        }, timeBeforeWarning)
    }

    private fun startGlobalCountdown() {
        warningCountdownTimer?.cancel()
        warningCountdownTimer = object : CountDownTimer(WARNING_TIME_MS, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                val secondsLeft = millisUntilFinished / 1000
                currentActivity?.let { activity ->
                    AdOverlayHelper.showCountdownOverlay(activity, secondsLeft)
                }
            }

            override fun onFinish() {
                currentActivity?.let { activity ->
                    AdOverlayHelper.removeOverlay(activity)
                    showGlobalAd(activity)
                }
            }
        }.start()
    }

    private fun showGlobalAd(activity: Activity) {
        // Double check if an ad is actually sitting ready in memory
        if (startAppAd?.isReady == true) {
            Log.d("GlobalAdManager", "Ad is ready! Displaying over active activity surface...")
            startAppAd?.showAd()
        } else {
            Log.w("GlobalAdManager", "Ad was not ready in memory when countdown ended. Forcing emergency live show...")
            // Fallback: If preloading was too slow, trigger a direct, un-cached display attempt
            StartAppAd.showAd(activity)
        }

        // Loop resets: Preload the ad for the next interval right away
        preloadNextAd(activity)
        startGlobalAdScheduler()
    }

    // ─── Activity Lifecycle Listeners ─────────────────────────────────────────

    override fun onActivityResumed(activity: Activity) {
        currentActivity = activity

        // As soon as any screen wakes up, check and ensure we have an ad caching in background
        if (startAppAd == null || startAppAd?.isReady == false) {
            preloadNextAd(activity)
        }
    }

    override fun onActivityPaused(activity: Activity) {
        AdOverlayHelper.removeOverlay(activity)
        if (currentActivity == activity) {
            currentActivity = null
        }
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
    override fun onActivityStarted(activity: Activity) {}
    override fun onActivityStopped(activity: Activity) {}
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
    override fun onActivityDestroyed(activity: Activity) {}
}