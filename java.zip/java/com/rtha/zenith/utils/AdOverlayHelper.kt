package com.rtha.zenith.utils

import android.graphics.Color
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView

object AdOverlayHelper {
    private const val OVERLAY_TAG_ID = 998877 // Unique ID to find and remove our overlay

    fun showCountdownOverlay(activity: android.app.Activity, secondsLeft: Long) {
        // Find the root layout decor view of the current active activity
        val rootView = activity.window.decorView.findViewById<ViewGroup>(android.R.id.content) ?: return

        // Check if our overlay text view is already attached to this screen
        var textView = rootView.findViewWithTag<TextView>(OVERLAY_TAG_ID)

        if (textView == null) {
            textView = TextView(activity).apply {
                tag = OVERLAY_TAG_ID
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor("#88000000")) // Semi-transparent black

                // Safe native sizing: 12 SP converted directly to pixels
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)

                // Convert padding from DP to rough pixels safely
                val paddingPx = (10 * context.resources.displayMetrics.density).toInt()
                setPadding(paddingPx, paddingPx / 2, paddingPx, paddingPx / 2)
                gravity = Gravity.CENTER
            }

            // Position layout parameters explicitly to top-left
            val params = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                topMargin = 32 // Slightly lowered so it doesn't get cut off by status bars
                leftMargin = 32
            }

            rootView.addView(textView, params)
        }

        textView.text = "Ad in: ${secondsLeft}s"
        textView.visibility = View.VISIBLE
    }

    fun removeOverlay(activity: android.app.Activity) {
        val rootView = activity.window.decorView.findViewById<ViewGroup>(android.R.id.content) ?: return
        val textView = rootView.findViewWithTag<TextView>(OVERLAY_TAG_ID)
        if (textView != null) {
            rootView.removeView(textView)
        }
    }
}