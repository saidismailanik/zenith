package com.rtha.zenith.utils

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.*
import java.util.concurrent.ConcurrentHashMap

object StreamScraper {

    private const val TAG = "StreamScraper"
    private const val TIMEOUT_MS = 15_000L

    private val streamCache = ConcurrentHashMap<String, String>()

    private const val DESKTOP_USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
                "AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Safari/537.36"

    // Each provider receives the raw TMDB integer ID — e.g. 299535, 1265609
    // The ${id} template calls Int.toString() → always a plain decimal number
    // Examples:  vidfast.pro/movie/299535   videasy.net/movie/299535
    enum class Provider(val buildUrl: (Int) -> String) {
        VIDFAST ({ id -> "https://vidfast.pro/movie/${id}"      }),
        VIDEASY ({ id -> "https://player.videasy.net/movie/${id}"      }),
        VIDSRC  ({ id -> "https://vidsrc.to/embed/movie/${id}" }),
        EMBED_SU({ id -> "https://embed.su/embed/movie/${id}"  })
    }

    private val providerList = listOf(
        Provider.VIDFAST,
        Provider.VIDEASY,
        Provider.VIDSRC,
        Provider.EMBED_SU
    )

    fun resolve(
        context: Context,
        tmdbMovieId: Int,
        onResult: (String?) -> Unit
    ) {
        val cacheKey = tmdbMovieId.toString()

        streamCache[cacheKey]?.let {
            Log.d(TAG, "Cache hit for tmdbId=$cacheKey")
            Handler(Looper.getMainLooper()).post { onResult(it) }
            return
        }

        tryNextProvider(context, tmdbMovieId, providerList, 0, onResult)
    }

    fun clearCache(tmdbMovieId: Int) = streamCache.remove(tmdbMovieId.toString())
    fun clearAllCache() = streamCache.clear()

    @SuppressLint("SetJavaScriptEnabled")
    private fun tryNextProvider(
        context: Context,
        tmdbMovieId: Int,
        providers: List<Provider>,
        index: Int,
        onResult: (String?) -> Unit
    ) {
        if (index >= providers.size) {
            Log.w(TAG, "All providers exhausted for tmdbId=$tmdbMovieId")
            Handler(Looper.getMainLooper()).post { onResult(null) }
            return
        }

        val provider = providers[index]
        val embedUrl = provider.buildUrl(tmdbMovieId)
        Log.d(TAG, "Trying ${provider.name}: $embedUrl")

        var resolved = false
        val handler = Handler(Looper.getMainLooper())

        val webView = WebView(context).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                javaScriptCanOpenWindowsAutomatically = true
                mediaPlaybackRequiresUserGesture = false
                userAgentString = DESKTOP_USER_AGENT
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                cacheMode = WebSettings.LOAD_NO_CACHE
                allowFileAccess = false
                allowContentAccess = false
            }

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest
                ): WebResourceResponse? {
                    val reqUrl = request.url.toString()
                    if (isStreamUrl(reqUrl) && !resolved) {
                        resolved = true
                        Log.d(TAG, "Stream intercepted [${provider.name}]: $reqUrl")
                        streamCache[tmdbMovieId.toString()] = reqUrl
                        handler.post {
                            stopLoading()
                            destroy()
                            onResult(reqUrl)
                        }
                    }
                    return super.shouldInterceptRequest(view, request)
                }
            }
        }

        // 15s timeout — move to next provider
        handler.postDelayed({
            if (!resolved) {
                Log.w(TAG, "Timeout [${provider.name}] — trying next…")
                webView.stopLoading()
                webView.destroy()
                tryNextProvider(context, tmdbMovieId, providers, index + 1, onResult)
            }
        }, TIMEOUT_MS)

        webView.loadUrl(embedUrl)
    }

    private fun isStreamUrl(url: String): Boolean {
        val lower = url.lowercase()
        return lower.contains(".m3u8")         ||
                lower.contains(".mp4")          ||
                lower.contains("chunklist")     ||
                lower.contains("playlist.m3u8") ||
                (lower.contains("manifest") &&
                        (lower.contains("hls") || lower.contains("dash")))
    }
}