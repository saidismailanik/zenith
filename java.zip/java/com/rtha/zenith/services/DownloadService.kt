package com.rtha.zenith.services

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.rtha.zenith.R
import com.rtha.zenith.models.AppDatabase
import com.rtha.zenith.models.OfflineMovie
import com.rtha.zenith.models.toEntity
import kotlinx.coroutines.*
import java.io.*
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

class DownloadService : Service() {

    companion object {
        const val TAG = "DownloadService"
        const val DESKTOP_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
                    "AppleWebKit/537.36 (KHTML, like Gecko) " +
                    "Chrome/124.0.0.0 Safari/537.36"
        const val ACTION_START_DOWNLOAD    = "com.moviestream.START_DOWNLOAD"
        const val ACTION_DOWNLOAD_PROGRESS = "com.moviestream.DOWNLOAD_PROGRESS"
        const val ACTION_DOWNLOAD_COMPLETE = "com.moviestream.DOWNLOAD_COMPLETE"
        const val ACTION_DOWNLOAD_ERROR    = "com.moviestream.DOWNLOAD_ERROR"

        const val EXTRA_MOVIE_ID     = "movie_id"
        const val EXTRA_MOVIE_TITLE  = "movie_title"
        const val EXTRA_POSTER_PATH  = "poster_path"
        const val EXTRA_VOTE_AVERAGE = "vote_average"
        const val EXTRA_RELEASE_DATE = "release_date"
        const val EXTRA_RUNTIME      = "runtime"
        const val EXTRA_STREAM_URL   = "stream_url"
        const val EXTRA_IMDB_ID      = "imdb_id"
        const val EXTRA_PROGRESS     = "progress"
        const val EXTRA_ERROR_MSG    = "error_msg"

        const val CHANNEL_ID  = "download_channel"
        const val NOTIF_ID    = 1001
        const val BUFFER_SIZE = 65536  // 64 KB

        val activeDownloads = HashSet<Int>()
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var db: AppDatabase
    private lateinit var broadcaster: LocalBroadcastManager
    private val downloadJobs = HashMap<Int, Job>()

    // ─── Lifecycle ────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        db = AppDatabase.getInstance(this)
        broadcaster = LocalBroadcastManager.getInstance(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START_DOWNLOAD) {
            val movieId     = intent.getIntExtra(EXTRA_MOVIE_ID, -1)
            val title       = intent.getStringExtra(EXTRA_MOVIE_TITLE) ?: "Unknown"
            val posterPath  = intent.getStringExtra(EXTRA_POSTER_PATH)
            val rating      = intent.getDoubleExtra(EXTRA_VOTE_AVERAGE, 0.0)
            val releaseDate = intent.getStringExtra(EXTRA_RELEASE_DATE) ?: ""
            val runtime     = if (intent.hasExtra(EXTRA_RUNTIME)) intent.getIntExtra(EXTRA_RUNTIME, 0) else null
            val streamUrl   = intent.getStringExtra(EXTRA_STREAM_URL) ?: return START_NOT_STICKY
            val imdbId      = intent.getStringExtra(EXTRA_IMDB_ID)  // may be null

            if (movieId != -1 && !activeDownloads.contains(movieId)) {
                startForegroundNotification(title)
                startDownload(movieId, title, posterPath, rating, releaseDate, runtime, streamUrl, imdbId)
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ─── Download Logic ───────────────────────────────────────────────────────

    private fun startDownload(
        movieId: Int,
        title: String,
        posterPath: String?,
        rating: Double,
        releaseDate: String,
        runtime: Int?,
        streamUrl: String,
        imdbId: String?
    ) {
        activeDownloads.add(movieId)

        val job = scope.launch {
            try {
                // ── Step 1: Download video ────────────────────────────────────
                val outputFile = getOutputFile(movieId, title)
                if (streamUrl.contains(".m3u8")) {
                    downloadHls(movieId, streamUrl, outputFile)
                } else {
                    downloadDirect(movieId, streamUrl, outputFile)
                }

                // ── Step 2: Save to Room (no subtitleDir yet) ─────────────────
                val offlineMovie = OfflineMovie(
                    id = movieId,
                    title = title,
                    posterPath = posterPath,
                    voteAverage = rating,
                    releaseDate = releaseDate,
                    runtime = runtime,
                    localFilePath = outputFile.absolutePath,
                )
                db.offlineMovieDao().insertMovie(offlineMovie.toEntity())

                // ── Step 5: Broadcast complete ────────────────────────────────
                broadcastProgress(movieId, 100, complete = true)
                updateNotification(title, 100, complete = true)

            } catch (e: CancellationException) {
                Log.d(TAG, "Download cancelled for $movieId")
            } catch (e: Exception) {
                Log.e(TAG, "Download failed for $movieId", e)
                broadcastError(movieId, e.message ?: "Unknown error")
            } finally {
                activeDownloads.remove(movieId)
                downloadJobs.remove(movieId)
                if (activeDownloads.isEmpty()) stopSelf()
            }
        }

        downloadJobs[movieId] = job


    }

    // ─── IMDB ID resolver ─────────────────────────────────────────────────────

    private suspend fun resolveImdbId(movieId: Int): String? {
        return try {
            val apiKey = com.rtha.zenith.BuildConfig.TMDB_API_KEY
            val url = "https://api.themoviedb.org/3/movie/$movieId/external_ids?api_key=$apiKey"
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 8_000
            conn.readTimeout = 8_000
            conn.setRequestProperty("User-Agent", DESKTOP_UA)
            conn.connect()
            val body = conn.inputStream.bufferedReader().readText()
            conn.disconnect()
            val json = org.json.JSONObject(body)
            json.optString("imdb_id").takeIf { it.isNotBlank() && it != "null" }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to resolve IMDB ID for $movieId: ${e.message}")
            null
        }
    }

    // ─── HLS Downloader ───────────────────────────────────────────────────────

    private suspend fun downloadHls(movieId: Int, m3u8Url: String, outputFile: File) {
        val segments = parseM3u8(m3u8Url)
        if (segments.isEmpty()) throw IOException("No segments found in M3U8: $m3u8Url")

        val baseUrl = m3u8Url.substringBeforeLast("/") + "/"
        val total = segments.size
        Log.d(TAG, "Starting HLS download: $total segments, base=$baseUrl")

        FileOutputStream(outputFile).use { fos ->
            val bos = BufferedOutputStream(fos, BUFFER_SIZE)
            segments.forEachIndexed { idx, segment ->
                val segUrl = resolveUrl(baseUrl, segment)
                Log.d(TAG, "Segment ${idx + 1}/$total: $segUrl")
                downloadSegment(segUrl, bos)
                bos.flush()
                fos.channel.force(true)

                val progress = ((idx + 1).toFloat() / total * 99).toInt()
                broadcastProgress(movieId, progress)
                updateNotification("Downloading…", progress)
            }
            bos.flush()
            fos.channel.force(true)
        }
    }

    private suspend fun parseM3u8(url: String): List<String> = withContext(Dispatchers.IO) {
        val segments = mutableListOf<String>()
        try {
            val conn = openConnection(url)
            val responseCode = conn.responseCode
            if (responseCode != HttpURLConnection.HTTP_OK) {
                Log.e(TAG, "M3U8 fetch failed: HTTP $responseCode for $url")
                conn.disconnect()
                return@withContext segments
            }

            val text = conn.inputStream.bufferedReader(Charsets.UTF_8).readText()
            conn.disconnect()
            Log.d(TAG, "M3U8 (${text.length} chars):\n${text.take(500)}")

            val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
            val isMaster = lines.any { it.startsWith("#EXT-X-STREAM-INF") }

            if (isMaster) {
                var bestBandwidth = -1
                var bestUrl: String? = null
                var i = 0
                while (i < lines.size) {
                    val line = lines[i]
                    if (line.startsWith("#EXT-X-STREAM-INF")) {
                        val bandwidth = Regex("BANDWIDTH=(\\d+)")
                            .find(line)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                        val nextLine = lines.getOrNull(i + 1)
                        if (nextLine != null && !nextLine.startsWith("#")) {
                            if (bandwidth > bestBandwidth) {
                                bestBandwidth = bandwidth
                                bestUrl = nextLine
                            }
                        }
                    }
                    i++
                }
                if (bestUrl != null) {
                    val resolvedVariant = resolveUrl(url, bestUrl)
                    Log.d(TAG, "Master → variant (bandwidth=$bestBandwidth): $resolvedVariant")
                    return@withContext parseM3u8(resolvedVariant)
                } else {
                    Log.e(TAG, "Master playlist: no variant URL found")
                }
            } else {
                lines.forEach { line ->
                    if (!line.startsWith("#") && line.isNotBlank()) segments.add(line)
                }
                Log.d(TAG, "Media playlist: ${segments.size} segments")
            }
        } catch (e: Exception) {
            Log.e(TAG, "M3U8 parse error: ${e.message}", e)
        }
        segments
    }

    private fun resolveUrl(base: String, path: String): String {
        return when {
            path.startsWith("http://") || path.startsWith("https://") -> path
            path.startsWith("//") -> "https:$path"
            path.startsWith("/") -> {
                val uri = URI(base)
                "${uri.scheme}://${uri.host}$path"
            }
            else -> base.substringBeforeLast("/") + "/$path"
        }
    }

    private suspend fun downloadSegment(url: String, out: OutputStream) = withContext(Dispatchers.IO) {
        var retries = 3
        while (retries > 0) {
            try {
                val conn = openConnection(url)
                val code = conn.responseCode
                if (code != HttpURLConnection.HTTP_OK && code != 206) {
                    conn.disconnect()
                    throw IOException("Segment HTTP $code: $url")
                }
                BufferedInputStream(conn.inputStream, BUFFER_SIZE).use { bis ->
                    val buffer = ByteArray(BUFFER_SIZE)
                    var read: Int
                    while (bis.read(buffer).also { read = it } != -1) out.write(buffer, 0, read)
                }
                conn.disconnect()
                return@withContext
            } catch (e: IOException) {
                retries--
                Log.w(TAG, "Segment retry ($retries left): ${e.message}")
                if (retries == 0) throw e
                delay(1000L)
            }
        }
    }

    // ─── Direct MP4 Downloader ────────────────────────────────────────────────

    private suspend fun downloadDirect(movieId: Int, url: String, outputFile: File) {
        withContext(Dispatchers.IO) {
            val conn = openConnection(url)
            val totalBytes = conn.contentLengthLong.takeIf { it > 0 } ?: -1L
            var downloaded = 0L

            FileOutputStream(outputFile).use { fos ->
                BufferedInputStream(conn.inputStream, BUFFER_SIZE).use { bis ->
                    val buffer = ByteArray(BUFFER_SIZE)
                    var read: Int
                    var lastProgress = -1
                    while (bis.read(buffer).also { read = it } != -1) {
                        fos.write(buffer, 0, read)
                        downloaded += read
                        val progress = if (totalBytes > 0)
                            (downloaded * 100 / totalBytes).toInt().coerceIn(0, 99) else -1
                        if (progress != lastProgress && progress >= 0) {
                            lastProgress = progress
                            broadcastProgress(movieId, progress)
                            updateNotification("Downloading…", progress)
                        }
                    }
                    fos.channel.force(true)
                }
            }
            conn.disconnect()
        }
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private fun openConnection(url: String): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 5_000
        conn.readTimeout    = 5_000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", DESKTOP_UA)
        conn.setRequestProperty("Accept", "*/*")
        conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        conn.setRequestProperty("Origin", "https://vidfast.pro")
        conn.setRequestProperty("Referer", "https://vidfast.pro/")
        conn.connect()
        return conn
    }

    private fun getOutputFile(movieId: Int, title: String): File {
        val dir = File(getExternalFilesDir(null), "downloads").apply { mkdirs() }
        val safe = title.replace(Regex("[^A-Za-z0-9 ]"), "").trim().replace(" ", "_")
        return File(dir, "${safe}_${movieId}.ts")
    }

    private fun broadcastProgress(movieId: Int, progress: Int, complete: Boolean = false) {
        val intent = Intent(if (complete) ACTION_DOWNLOAD_COMPLETE else ACTION_DOWNLOAD_PROGRESS).apply {
            putExtra(EXTRA_MOVIE_ID, movieId)
            putExtra(EXTRA_PROGRESS, progress)
        }
        broadcaster.sendBroadcast(intent)
    }

    private fun broadcastError(movieId: Int, message: String) {
        val intent = Intent(ACTION_DOWNLOAD_ERROR).apply {
            putExtra(EXTRA_MOVIE_ID, movieId)
            putExtra(EXTRA_ERROR_MSG, message)
        }
        broadcaster.sendBroadcast(intent)
    }

    // ─── Notifications ────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Movie Downloads",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background movie download progress"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun startForegroundNotification(title: String) {
        val notification = buildNotification(title, 0, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun updateNotification(title: String, progress: Int, complete: Boolean = false) {
        val notification = buildNotification(title, progress, complete)
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification)
    }

    private fun buildNotification(title: String, progress: Int, complete: Boolean): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(if (complete) "Download Complete" else "Downloading Movie")
            .setContentText(if (complete) "$title saved" else "$title — $progress%")
            .setSmallIcon(R.drawable.ic_download)
            .setProgress(100, progress, false)
            .setOngoing(!complete)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}