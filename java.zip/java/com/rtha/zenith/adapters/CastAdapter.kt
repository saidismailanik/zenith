package com.rtha.zenith.adapters


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.rtha.zenith.R
import com.rtha.zenith.models.CastMember

class CastAdapter(
    private val cast: List<CastMember>
) : RecyclerView.Adapter<CastAdapter.CastViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CastViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_cast, parent, false)
        return CastViewHolder(view)
    }

    override fun onBindViewHolder(holder: CastViewHolder, position: Int) {
        holder.bind(cast[position])
    }

    override fun getItemCount() = cast.size

    inner class CastViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivProfile: ImageView = itemView.findViewById(R.id.ivCastProfile)
        private val tvName: TextView     = itemView.findViewById(R.id.tvCastName)
        private val tvCharacter: TextView = itemView.findViewById(R.id.tvCastCharacter)

        fun bind(cast: CastMember) {
            tvName.text      = cast.name
            tvCharacter.text = cast.character

            Glide.with(itemView.context)
                .load(cast.profileUrl)
                .placeholder(R.drawable.placeholder_cast)
                .transition(DrawableTransitionOptions.withCrossFade())
                .circleCrop()
                .into(ivProfile)
        }
    }
}