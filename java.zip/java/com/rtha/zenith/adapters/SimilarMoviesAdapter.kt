package com.rtha.zenith.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.rtha.zenith.R
import com.rtha.zenith.models.Movie

class SimilarMoviesAdapter(
    private val movies: List<Movie>,
    private val onClick: (Movie) -> Unit
) : RecyclerView.Adapter<SimilarMoviesAdapter.SimilarViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SimilarViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_similar_movie, parent, false)
        return SimilarViewHolder(view)
    }

    override fun onBindViewHolder(holder: SimilarViewHolder, position: Int) {
        holder.bind(movies[position])
    }

    override fun getItemCount() = movies.size

    inner class SimilarViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivPoster: ImageView = itemView.findViewById(R.id.ivSimilarPoster)

        fun bind(movie: Movie) {
            Glide.with(itemView.context)
                .load(movie.posterUrl)
                .placeholder(R.drawable.placeholder_poster)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(ivPoster)

            itemView.setOnClickListener { onClick(movie) }
        }
    }
}