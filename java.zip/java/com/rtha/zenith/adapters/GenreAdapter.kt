package com.rtha.zenith.adapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import  com.rtha.zenith.R
import com.rtha.zenith.models.GenreTab

class GenreAdapter(
    private val genres: MutableList<GenreTab> = mutableListOf(),
    private val onGenreSelected: (GenreTab) -> Unit
) : RecyclerView.Adapter<GenreAdapter.GenreViewHolder>() {

    private var selectedPosition = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GenreViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_genre_tab, parent, false)
        return GenreViewHolder(view)
    }

    override fun onBindViewHolder(holder: GenreViewHolder, position: Int) {
        holder.bind(genres[position], position == selectedPosition)
    }

    override fun getItemCount() = genres.size

    fun submitList(newGenres: List<GenreTab>) {
        genres.clear()
        genres.addAll(newGenres)
        notifyDataSetChanged()
    }

    inner class GenreViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvGenre: TextView = itemView.findViewById(R.id.tvGenreName)

        fun bind(genre: GenreTab, isSelected: Boolean) {
            tvGenre.text = genre.name

            if (isSelected) {
                tvGenre.setBackgroundResource(R.drawable.bg_genre_selected)
                tvGenre.setTextColor(Color.WHITE)
            } else {
                tvGenre.setBackgroundResource(R.drawable.bg_genre_unselected)
                tvGenre.setTextColor(Color.parseColor("#AAAAAA"))
            }

            itemView.setOnClickListener {
                val prev = selectedPosition
                selectedPosition = adapterPosition
                notifyItemChanged(prev)
                notifyItemChanged(selectedPosition)
                onGenreSelected(genre)
            }
        }
    }
}
