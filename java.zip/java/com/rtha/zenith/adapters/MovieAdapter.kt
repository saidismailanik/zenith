package com.rtha.zenith.adapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import  com.rtha.zenith.R
import com.rtha.zenith.models.DownloadState
import com.rtha.zenith.models.Movie
import com.rtha.zenith.services.DownloadService
import java.io.File

class MovieAdapter(
    private val mode: Mode = Mode.HOME,
    private val onDownloadClick: (Movie) -> Unit = {},
    private val onDeleteClick: (Movie) -> Unit = {},
    private val onCardClick: (Movie) -> Unit = {}
) : ListAdapter<Movie, MovieAdapter.MovieViewHolder>(DIFF_CALLBACK) {

    enum class Mode { HOME, DOWNLOADS }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_movie, parent, false)
        return MovieViewHolder(view)
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class MovieViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivPoster: ImageView   = itemView.findViewById(R.id.ivPoster)
        private val tvTitle: TextView     = itemView.findViewById(R.id.tvTitle)
        private val tvRating: TextView    = itemView.findViewById(R.id.tvRating)
        private val tvYear: TextView      = itemView.findViewById(R.id.tvYear)
        private val tvRuntime: TextView   = itemView.findViewById(R.id.tvRuntime)
        private val btnAction: Button     = itemView.findViewById(R.id.btnAction)

        fun bind(movie: Movie) {
            tvTitle.text   = movie.title
            tvRating.text  = "⭐ ${movie.ratingFormatted}"
            tvYear.text    = movie.releaseYear
            tvRuntime.text = movie.runtimeFormatted

            Glide.with(itemView.context)
                .load(movie.posterUrl)
                .placeholder(R.drawable.placeholder_poster)
                .error(R.drawable.placeholder_poster)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(ivPoster)

            itemView.setOnClickListener { onCardClick(movie) }

            when (mode) {
                Mode.HOME      -> bindHomeButton(movie)
                Mode.DOWNLOADS -> bindDeleteButton(movie)
            }
        }

        private fun bindHomeButton(movie: Movie) {
            val liveState = when {
                movie.downloadState == DownloadState.COMPLETED        -> DownloadState.COMPLETED
                DownloadService.Companion.activeDownloads.contains(movie.id)    -> DownloadState.DOWNLOADING
                else                                                  -> movie.downloadState
            }

            val hasRuntime = movie.runtime != null && movie.runtime!! > 0

            when (liveState) {
                DownloadState.NONE -> {
                    if (hasRuntime) {
                        btnAction.text = "📥 Download"
                        btnAction.isEnabled = true
                        btnAction.setBackgroundColor(Color.parseColor("#1E88E5"))
                        btnAction.setOnClickListener { onDownloadClick(movie) }
                    } else {
                        btnAction.text = "🕐 Not Available"
                        btnAction.isEnabled = false
                        btnAction.setBackgroundColor(Color.parseColor("#444466"))
                        btnAction.setOnClickListener(null)
                    }
                }
                DownloadState.DOWNLOADING -> {
                    btnAction.text = "${movie.downloadProgress}%"
                    btnAction.isEnabled = false
                    btnAction.setBackgroundColor(Color.parseColor("#FB8C00"))
                }
                DownloadState.COMPLETED -> {
                    btnAction.text = "✓ Saved"
                    btnAction.isEnabled = false
                    btnAction.setBackgroundColor(Color.parseColor("#43A047"))
                }
            }
        }

        private fun bindDeleteButton(movie: Movie) {
            // Show runtime + file size together
            val runtimeText = movie.runtime?.let { "⏳ ${it} mins" } ?: "⏳ --"
            val sizeText = movie.localFilePath?.let { path ->
                val file = File(path)
                if (file.exists()) "💾 ${getFileSizeReadable(file)}" else "💾 --"
            } ?: "💾 --"

            tvRuntime.text = "$runtimeText  •  $sizeText"

            btnAction.text = "🗑 Delete"
            btnAction.isEnabled = true
            btnAction.setBackgroundColor(Color.parseColor("#C62828"))
            btnAction.setOnClickListener { onDeleteClick(movie) }
        }

        private fun getFileSizeReadable(file: File): String {
            val bytes = file.length()
            return when {
                bytes >= 1_073_741_824 -> String.format("%.2f GB", bytes / 1_073_741_824.0)
                bytes >= 1_048_576     -> String.format("%.1f MB", bytes / 1_048_576.0)
                bytes >= 1_024         -> String.format("%.0f KB", bytes / 1_024.0)
                else                   -> "$bytes B"
            }
        }
    }

    // Update a single movie's download progress without full list refresh
    fun updateDownloadProgress(movieId: Int, progress: Int) {
        currentList.indexOfFirst { it.id == movieId }.takeIf { it >= 0 }?.let { idx ->
            currentList[idx].downloadProgress = progress
            currentList[idx].downloadState    = DownloadState.DOWNLOADING
            notifyItemChanged(idx)
        }
    }

    fun markDownloadComplete(movieId: Int) {
        currentList.indexOfFirst { it.id == movieId }.takeIf { it >= 0 }?.let { idx ->
            currentList[idx].downloadState    = DownloadState.COMPLETED
            currentList[idx].downloadProgress = 100
            notifyItemChanged(idx)
        }
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Movie>() {
            override fun areItemsTheSame(a: Movie, b: Movie) = a.id == b.id
            override fun areContentsTheSame(a: Movie, b: Movie) =
                a.downloadState == b.downloadState &&
                a.downloadProgress == b.downloadProgress &&
                a.runtime == b.runtime
        }
    }
}
