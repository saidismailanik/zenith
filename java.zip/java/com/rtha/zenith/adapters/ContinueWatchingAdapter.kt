package com.rtha.zenith.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.rtha.zenith.R
import com.rtha.zenith.models.WatchProgressEntity

class ContinueWatchingAdapter(
    private val onItemClick: (WatchProgressEntity) -> Unit,
    private val onRemoveClick: (WatchProgressEntity) -> Unit
) : ListAdapter<WatchProgressEntity, ContinueWatchingAdapter.ViewHolder>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<WatchProgressEntity>() {
            override fun areItemsTheSame(a: WatchProgressEntity, b: WatchProgressEntity) =
                a.movieId == b.movieId
            override fun areContentsTheSame(a: WatchProgressEntity, b: WatchProgressEntity) =
                a == b
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_continue_watching, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val ivThumb: ImageView   = view.findViewById(R.id.ivThumb)
        private val tvTitle: TextView    = view.findViewById(R.id.tvTitle)
        private val tvProgress: TextView = view.findViewById(R.id.tvProgress)
        private val progressBar: ProgressBar = view.findViewById(R.id.progressBar)
        private val btnRemove: View      = view.findViewById(R.id.btnRemove)

        fun bind(item: WatchProgressEntity) {
            tvTitle.text = item.title

            // Format remaining time e.g. "45 min left"
            val remainingMs = item.durationMs - item.positionMs
            val remainingMin = (remainingMs / 60_000).toInt()
            tvProgress.text = if (remainingMin > 0) "$remainingMin min left" else "Almost done"

            // Progress bar 0-100
            val percent = ((item.positionMs.toFloat() / item.durationMs) * 100).toInt()
            progressBar.progress = percent

            // Backdrop thumbnail
            val backdropUrl = item.backdropPath?.let {
                "https://image.tmdb.org/t/p/w780$it"
            } ?: item.posterPath?.let {
                "https://image.tmdb.org/t/p/w500$it"
            }

            Glide.with(itemView.context)
                .load(backdropUrl)
                .placeholder(R.drawable.placeholder_poster)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(ivThumb)

            itemView.setOnClickListener { onItemClick(item) }
            btnRemove.setOnClickListener { onRemoveClick(item) }
        }
    }
}