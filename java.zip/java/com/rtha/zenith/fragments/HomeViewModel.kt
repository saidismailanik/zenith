package com.rtha.zenith.fragments

import androidx.lifecycle.*
import com.rtha.zenith.models.*
import com.rtha.zenith.network.MovieRepository
import kotlinx.coroutines.*

class HomeViewModel : ViewModel() {

    private val repo = MovieRepository()

    private val _movies = MutableLiveData<List<Movie>>(emptyList())
    val movies: LiveData<List<Movie>> = _movies

    private val _genres = MutableLiveData<List<GenreTab>>()
    val genres: LiveData<List<GenreTab>> = _genres

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _isLoadingMore = MutableLiveData(false)
    val isLoadingMore: LiveData<Boolean> = _isLoadingMore

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    private var currentGenreId: Int? = null
    private var currentQuery: String = ""
    private var currentPage = 1
    private var isLastPage = false
    private var searchJob: Job? = null

    private val defaultGenres = listOf(
        GenreTab(0,     "Popular",   isSelected = true),
        GenreTab(28,    "Action"),
        GenreTab(12,    "Adventure"),
        GenreTab(35,    "Comedy"),
        GenreTab(27,    "Horror"),
        GenreTab(878,   "Sci-Fi"),
        GenreTab(18,    "Drama"),
        GenreTab(10749, "Romance"),
        GenreTab(53,    "Thriller")
    )

    init {
        _genres.value = defaultGenres
        loadMovies()
    }

    // ─── Initial Load / Genre Change ──────────────────────────────────────────

    fun loadMovies(genreId: Int? = null) {
        currentGenreId = genreId
        currentQuery   = ""
        currentPage    = 1
        isLastPage     = false
        _movies.value  = emptyList()

        viewModelScope.launch {
            _isLoading.value = true
            _error.value     = null
            fetchPage(currentPage)
            _isLoading.value = false
        }
    }

    // ─── Load Next Page ───────────────────────────────────────────────────────

    fun loadNextPage() {
        if (_isLoadingMore.value == true || isLastPage || _isLoading.value == true) return

        viewModelScope.launch {
            _isLoadingMore.value = true
            currentPage++
            fetchPage(currentPage)
            _isLoadingMore.value = false
        }
    }

    // ─── Search ───────────────────────────────────────────────────────────────

    fun search(query: String) {
        searchJob?.cancel()

        if (query.isBlank()) {
            loadMovies(currentGenreId)
            return
        }

        currentQuery  = query
        currentPage   = 1
        isLastPage    = false
        _movies.value = emptyList()

        searchJob = viewModelScope.launch {
            delay(400)
            _isLoading.value = true
            val result = repo.searchMovies(query, currentPage)
            result.onSuccess { newMovies ->
                if (newMovies.isEmpty()) isLastPage = true
                val withRuntime = fetchRuntimes(newMovies)
                val valid = withRuntime.filter { it.runtime != null && it.runtime!! > 0 }
                _movies.value = valid
            }.onFailure {
                _error.value = it.message
            }
            _isLoading.value = false
        }
    }

    fun loadNextSearchPage() {
        if (_isLoadingMore.value == true || isLastPage || currentQuery.isBlank()) return

        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            _isLoadingMore.value = true
            currentPage++
            val result = repo.searchMovies(currentQuery, currentPage)
            result.onSuccess { newMovies ->
                if (newMovies.isEmpty()) {
                    isLastPage = true
                } else {
                    val withRuntime = fetchRuntimes(newMovies)
                    val valid = withRuntime.filter { it.runtime != null && it.runtime!! > 0 }
                    val combined = (_movies.value ?: emptyList()) + valid
                    _movies.value = combined
                }
            }.onFailure {
                _error.value = it.message
            }
            _isLoadingMore.value = false
        }
    }

    // ─── Internal ─────────────────────────────────────────────────────────────

    private suspend fun fetchPage(page: Int) {
        val result = if (currentQuery.isNotBlank()) {
            repo.searchMovies(currentQuery, page)
        } else if (currentGenreId == null || currentGenreId == 0) {
            repo.getPopularMovies(page)
        } else {
            repo.getMoviesByGenre(currentGenreId!!, page)
        }

        result.onSuccess { newMovies ->
            if (newMovies.isEmpty()) {
                isLastPage = true
            } else {
                // Filter out movies with missing critical data
                val filtered = newMovies.filter { movie ->
                    movie.posterPath != null &&
                            movie.releaseDate.isNotBlank() &&
                            movie.voteAverage > 0.0 &&
                            movie.overview.isNotBlank()
                }

                val withRuntime = fetchRuntimes(filtered)

                // Further filter out movies with no runtime after detail fetch
                val valid = withRuntime.filter { it.runtime != null && it.runtime!! > 0 }

                val existing  = _movies.value ?: emptyList()
                _movies.value = if (page == 1) valid else existing + valid
            }
        }.onFailure {
            _error.value = it.message
        }
    }

    fun applyDownloadedState(downloadedIds: Set<Int>, activeIds: Set<Int>) {
        val current = _movies.value ?: return
        _movies.value = current.map { movie ->
            movie.copy(
                downloadState = when {
                    downloadedIds.contains(movie.id) -> DownloadState.COMPLETED
                    activeIds.contains(movie.id)     -> DownloadState.DOWNLOADING
                    else                             -> DownloadState.NONE
                }
            )
        }
    }

    private suspend fun fetchRuntimes(movies: List<Movie>): List<Movie> {
        return coroutineScope {
            movies.map { movie ->
                async {
                    try {
                        val detail = repo.getMovieDetail(movie.id).getOrNull()
                        movie.copy(runtime = detail?.runtime)
                    } catch (e: Exception) {
                        movie
                    }
                }
            }.awaitAll()
        }
    }
}