package com.rtha.zenith.fragments

import com.rtha.zenith.services.DownloadService.Companion.EXTRA_RUNTIME
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.rtha.zenith.R
import com.rtha.zenith.activities.PlayerActivity
import com.rtha.zenith.adapters.ContinueWatchingAdapter
import com.rtha.zenith.adapters.GenreAdapter
import com.rtha.zenith.adapters.MovieAdapter
import com.rtha.zenith.databinding.FragmentHomeBinding
import com.rtha.zenith.models.AppDatabase
import com.rtha.zenith.models.DownloadState
import com.rtha.zenith.models.Movie
import com.rtha.zenith.services.DownloadService
import com.rtha.zenith.utils.StreamScraper
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {

    private lateinit var continueWatchingAdapter: ContinueWatchingAdapter

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private val viewModel: HomeViewModel by viewModels()
    private lateinit var movieAdapter: MovieAdapter
    private lateinit var genreAdapter: GenreAdapter
    private lateinit var db: AppDatabase
    private lateinit var broadcaster: LocalBroadcastManager

    // ─── Broadcast Receiver ───────────────────────────────────────────────────

    private val progressReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val movieId  = intent.getIntExtra(DownloadService.EXTRA_MOVIE_ID, -1)
            val progress = intent.getIntExtra(DownloadService.EXTRA_PROGRESS, 0)
            when (intent.action) {
                DownloadService.ACTION_DOWNLOAD_PROGRESS -> {
                    movieAdapter.updateDownloadProgress(movieId, progress)
                }
                DownloadService.ACTION_DOWNLOAD_COMPLETE -> {
                    movieAdapter.markDownloadComplete(movieId)
                    Toast.makeText(requireContext(), "✓ Download complete!", Toast.LENGTH_SHORT).show()
                }
                DownloadService.ACTION_DOWNLOAD_ERROR -> {
                    val msg = intent.getStringExtra(DownloadService.EXTRA_ERROR_MSG) ?: "Error"
                    Toast.makeText(requireContext(), "Download failed: $msg", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // ─── Lifecycle ────────────────────────────────────────────────────────────

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        db          = AppDatabase.getInstance(requireContext())
        broadcaster = LocalBroadcastManager.getInstance(requireContext())

        setupGenreRecycler()
        setupMovieRecycler()
        setupSearchView()
        observeViewModel()
        restoreDownloadStates()
        registerReceivers()
        setupContinueWatching()
    }

    override fun onResume() {
        super.onResume()
        restoreDownloadStates()
        loadContinueWatching()   // refresh on return from player
    }
    override fun onDestroyView() {
        broadcaster.unregisterReceiver(progressReceiver)
        _binding = null
        super.onDestroyView()
    }

    // ─── Setup ────────────────────────────────────────────────────────────────

    private fun setupContinueWatching() {
        continueWatchingAdapter = ContinueWatchingAdapter(
            onItemClick = { progress ->
                // Resume from saved position
                val intent = Intent(requireContext(), PlayerActivity::class.java).apply {
                    putExtra(PlayerActivity.EXTRA_STREAM_URL, progress.streamUrl)
                    putExtra(PlayerActivity.EXTRA_MOVIE_TITLE, progress.title)
                    putExtra(PlayerActivity.EXTRA_MOVIE_ID, progress.movieId)
                    putExtra("poster_path", progress.posterPath)
                    putExtra(PlayerActivity.EXTRA_BACKDROP_PATH, progress.backdropPath)
                    putExtra(PlayerActivity.EXTRA_VOTE_AVERAGE, progress.voteAverage)
                    putExtra(PlayerActivity.EXTRA_RELEASE_DATE_STR, progress.releaseDate)
                    putExtra(PlayerActivity.EXTRA_OVERVIEW, progress.overview)
                    progress.runtime?.let { putExtra(PlayerActivity.EXTRA_RUNTIME, it) }
                    putExtra("seek_position", progress.positionMs)  // resume here
                }
                startActivity(intent)
            },
            onRemoveClick = { progress ->
                lifecycleScope.launch {
                    db.watchProgressDao().delete(progress.movieId)
                }
            }
        )

        binding.rvContinueWatching.apply {
            layoutManager = LinearLayoutManager(
                requireContext(), LinearLayoutManager.HORIZONTAL, false
            )
            adapter = continueWatchingAdapter
        }

        loadContinueWatching()
    }

    private fun loadContinueWatching() {
        lifecycleScope.launch {
            db.watchProgressDao().getAll().collect { list ->
                if (_binding == null) return@collect
                continueWatchingAdapter.submitList(list)
                val hasItems = list.isNotEmpty()
                binding.tvContinueWatchingLabel.visibility = if (hasItems) View.VISIBLE else View.GONE
                binding.rvContinueWatching.visibility      = if (hasItems) View.VISIBLE else View.GONE
            }
        }
    }
    private fun setupGenreRecycler() {
        genreAdapter = GenreAdapter { genre ->
            viewModel.loadMovies(genre.id.takeIf { it != 0 })
        }
        binding.rvGenres.apply {
            layoutManager = LinearLayoutManager(
                requireContext(), LinearLayoutManager.HORIZONTAL, false
            )
            adapter = genreAdapter
        }
    }

    private fun setupMovieRecycler() {
        movieAdapter = MovieAdapter(
            mode            = MovieAdapter.Mode.HOME,
            onDownloadClick = ::onDownloadClicked,
            onCardClick     = ::onCardClicked
        )

        binding.rvMovies.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter       = movieAdapter

            // ── Pagination scroll listener ────────────────────────────────────
            addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)
                    if (dy <= 0) return  // only trigger on downward scroll

                    val lm          = layoutManager as LinearLayoutManager
                    val totalItems  = lm.itemCount
                    val lastVisible = lm.findLastVisibleItemPosition()

                    // Load next page when user is 5 items from the bottom
                    if (lastVisible >= totalItems - 5) {
                        viewModel.loadNextPage()
                    }
                }
            })
        }
    }

    private fun setupSearchView() {
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                viewModel.search(query ?: "")
                return true
            }
            override fun onQueryTextChange(newText: String?): Boolean {
                viewModel.search(newText ?: "")
                return true
            }
        })
    }

    // ─── Observers ────────────────────────────────────────────────────────────

    private fun observeViewModel() {
        viewModel.genres.observe(viewLifecycleOwner) { genres ->
            genres ?: return@observe
            genreAdapter.submitList(genres)
        }

        viewModel.movies.observe(viewLifecycleOwner) { movies ->
            movies ?: return@observe
            if (_binding == null) return@observe

            viewLifecycleOwner.lifecycleScope.launch {
                if (_binding == null) return@launch

                val downloadedIds = runCatching {
                    db.offlineMovieDao().getAllDownloadedIds().toSet()
                }.getOrDefault(emptySet())

                val activeIds = DownloadService.activeDownloads.toSet()

                if (_binding == null) return@launch

                val withStates = movies.map { movie ->
                    movie.copy(
                        downloadState = when {
                            downloadedIds.contains(movie.id) -> DownloadState.COMPLETED
                            activeIds.contains(movie.id)     -> DownloadState.DOWNLOADING
                            else                             -> DownloadState.NONE
                        }
                    )
                }

                if (_binding == null) return@launch
                movieAdapter.submitList(withStates)
            }
        }

        viewModel.isLoading.observe(viewLifecycleOwner) { loading ->
            loading ?: return@observe
            if (_binding == null) return@observe
            binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        }

        // Loading more indicator at bottom
        viewModel.isLoadingMore.observe(viewLifecycleOwner) { loading ->
            loading ?: return@observe
            if (_binding == null) return@observe
            binding.progressBarBottom.visibility = if (loading) View.VISIBLE else View.GONE
        }

        viewModel.error.observe(viewLifecycleOwner) { err ->
            err ?: return@observe
            Toast.makeText(requireContext(), err, Toast.LENGTH_LONG).show()
        }
    }

    private fun restoreDownloadStates() {
        viewLifecycleOwner.lifecycleScope.launch {
            if (_binding == null) return@launch

            val downloadedIds = db.offlineMovieDao().getAllDownloadedIds().toSet()
            val activeIds     = DownloadService.activeDownloads.toSet()

            if (_binding == null) return@launch

            val updatedList = movieAdapter.currentList.map { movie ->
                movie.copy(
                    downloadState = when {
                        downloadedIds.contains(movie.id) -> DownloadState.COMPLETED
                        activeIds.contains(movie.id)     -> DownloadState.DOWNLOADING
                        else                             -> DownloadState.NONE
                    }
                )
            }

            if (_binding == null) return@launch
            movieAdapter.submitList(updatedList)
            viewModel.applyDownloadedState(downloadedIds, activeIds)
        }
    }

    private fun registerReceivers() {
        val filter = IntentFilter().apply {
            addAction(DownloadService.ACTION_DOWNLOAD_PROGRESS)
            addAction(DownloadService.ACTION_DOWNLOAD_COMPLETE)
            addAction(DownloadService.ACTION_DOWNLOAD_ERROR)
        }
        broadcaster.registerReceiver(progressReceiver, filter)
    }

    // ─── Actions ──────────────────────────────────────────────────────────────

    private fun onDownloadClicked(movie: Movie) {
        movieAdapter.updateDownloadProgress(movie.id, 0)
        Toast.makeText(requireContext(), "🔍 Resolving stream…", Toast.LENGTH_SHORT).show()

        StreamScraper.resolve(requireContext(), movie.id) { streamUrl ->
            if (streamUrl == null) {
                Toast.makeText(requireContext(), "❌ Stream not found", Toast.LENGTH_LONG).show()
                movieAdapter.currentList.find { it.id == movie.id }?.downloadState =
                    DownloadState.NONE
                movieAdapter.notifyDataSetChanged()
                return@resolve
            }

            val intent = Intent(requireContext(), DownloadService::class.java).apply {
                action = DownloadService.ACTION_START_DOWNLOAD
                putExtra(DownloadService.EXTRA_MOVIE_ID,     movie.id)
                putExtra(DownloadService.EXTRA_MOVIE_TITLE,  movie.title)
                putExtra(DownloadService.EXTRA_POSTER_PATH,  movie.posterPath)
                putExtra(DownloadService.EXTRA_VOTE_AVERAGE, movie.voteAverage)
                putExtra(DownloadService.EXTRA_RELEASE_DATE, movie.releaseDate)
                movie.runtime?.let { putExtra(DownloadService.EXTRA_RUNTIME, it) }
                putExtra(DownloadService.EXTRA_STREAM_URL,   streamUrl)
            }
            requireContext().startService(intent)
        }
    }

    private fun onCardClicked(movie: Movie) {
        val bundle = Bundle().apply {
            putInt(MovieDetailFragment.ARG_MOVIE_ID,          movie.id)
            putString(MovieDetailFragment.ARG_MOVIE_TITLE,    movie.title)
            putString(MovieDetailFragment.ARG_POSTER_PATH,    movie.posterPath)
            putString(MovieDetailFragment.ARG_BACKDROP_PATH,  movie.backdropPath)
            putFloat(MovieDetailFragment.ARG_RATING,          movie.voteAverage.toFloat())
            putString(MovieDetailFragment.ARG_RELEASE_DATE,   movie.releaseDate)
            putString(MovieDetailFragment.ARG_OVERVIEW,       movie.overview)
            putInt(MovieDetailFragment.ARG_RUNTIME,           movie.runtime ?: -1)
        }
        findNavController().navigate(R.id.action_home_to_detail, bundle)
    }
}