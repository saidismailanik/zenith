package com.rtha.zenith.fragments

import com.rtha.zenith.services.DownloadService.Companion.EXTRA_RUNTIME
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.rtha.zenith.R
import com.rtha.zenith.activities.PlayerActivity
import com.rtha.zenith.adapters.CastAdapter
import com.rtha.zenith.adapters.SimilarMoviesAdapter
import com.rtha.zenith.databinding.FragmentMovieDetailBinding
import com.rtha.zenith.models.AppDatabase
import com.rtha.zenith.models.DownloadState
import com.rtha.zenith.models.Movie
import com.rtha.zenith.network.MovieRepository
import com.rtha.zenith.services.DownloadService
import com.rtha.zenith.utils.StreamScraper
import com.startapp.sdk.ads.banner.Banner
import com.startapp.sdk.ads.banner.BannerListener
import com.startapp.sdk.adsbase.StartAppSDK
import kotlinx.coroutines.launch

class MovieDetailFragment : Fragment() {

    private val TAG = "StartIoIntegration"

    private var bannerContainer: FrameLayout? = null
    private var startAppBanner: Banner? = null

    private var castAdapter: CastAdapter? = null
    private var similarAdapter: SimilarMoviesAdapter? = null
    private var _binding: FragmentMovieDetailBinding? = null
    private val binding get() = _binding!!

    private lateinit var db: AppDatabase
    private val repo = MovieRepository()
    private var currentMovie: Movie? = null

    companion object {
        const val ARG_MOVIE_ID      = "movie_id"
        const val ARG_MOVIE_TITLE   = "movie_title"
        const val ARG_POSTER_PATH   = "poster_path"
        const val ARG_BACKDROP_PATH = "backdrop_path"
        const val ARG_RATING        = "rating"
        const val ARG_RELEASE_DATE  = "release_date"
        const val ARG_OVERVIEW      = "overview"
        const val ARG_RUNTIME       = "runtime"
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMovieDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    private fun setupRecyclers() {
        binding.rvCast.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)

        binding.rvSimilar.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        db = AppDatabase.getInstance(requireContext())

        // Find the layout container for the banner ad (Reuse your FrameLayout)
        bannerContainer = view.findViewById(R.id.banner_container)

        // Force Start.io into test mode for verification
        StartAppSDK.setTestAdsEnabled(true)

        // Load Start.io banner inside the container
        loadStartIoBanner()

        val movieId      = arguments?.getInt(ARG_MOVIE_ID) ?: return
        val title        = arguments?.getString(ARG_MOVIE_TITLE) ?: ""
        val posterPath   = arguments?.getString(ARG_POSTER_PATH)
        val backdropPath = arguments?.getString(ARG_BACKDROP_PATH)
        val rating       = arguments?.getFloat(ARG_RATING)?.toDouble() ?: 0.0
        val releaseDate  = arguments?.getString(ARG_RELEASE_DATE) ?: ""
        val overview     = arguments?.getString(ARG_OVERVIEW) ?: ""
        val runtime      = arguments?.getInt(ARG_RUNTIME).takeIf { it != -1 }

        currentMovie = Movie(
            id           = movieId,
            title        = title,
            posterPath   = posterPath,
            backdropPath = backdropPath,
            voteAverage  = rating,
            releaseDate  = releaseDate,
            overview     = overview,
            runtime      = runtime
        )

        bindUI(currentMovie!!)
        checkDownloadState(movieId)
        fetchFullDetail(movieId)
        setupRecyclers()
        fetchCastAndSimilar(movieId)
    }

    private fun loadStartIoBanner() {
        val container = bannerContainer ?: return
        container.removeAllViews()

        // Create the Start.io programmatic banner view
        startAppBanner = Banner(requireActivity(), object : BannerListener {
            override fun onReceiveAd(banner: View?) {
                Log.d(TAG, "SUCCESS: Start.io banner ad successfully rendered!")
            }

            override fun onFailedToReceiveAd(banner: View?) {
                Log.e(TAG, "FAILED: Start.io banner could not fetch an ad inventory payload.")
            }

            override fun onImpression(p0: View?) {
                TODO("Not yet implemented")
            }

            fun Impression() {
                Log.d(TAG, "Start.io counted a user view impression.")
            }

            override fun onClick(banner: View?) {
                Log.d(TAG, "User clicked the banner ad.")
            }
        })

        // Inject the ad view directly into your existing FrameLayout container
        container.addView(startAppBanner)

        // Fetch the ad
        startAppBanner?.loadAd()
    }

    private fun fetchCastAndSimilar(movieId: Int) {
        // Cast
        lifecycleScope.launch {
            repo.getMovieCredits(movieId).onSuccess { credits ->
                if (_binding == null) return@onSuccess
                val topCast = credits.cast
                    .sortedBy { it.order }
                    .take(20)
                castAdapter = CastAdapter(topCast)
                binding.rvCast.adapter = castAdapter
            }
        }

        // Similar movies
        lifecycleScope.launch {
            repo.getSimilarMovies(movieId).onSuccess { movies ->
                if (_binding == null) return@onSuccess
                similarAdapter = SimilarMoviesAdapter(movies) { movie ->
                    val bundle = Bundle().apply {
                        putInt(ARG_MOVIE_ID,          movie.id)
                        putString(ARG_MOVIE_TITLE,    movie.title)
                        putString(ARG_POSTER_PATH,    movie.posterPath)
                        putString(ARG_BACKDROP_PATH,  movie.backdropPath)
                        putFloat(ARG_RATING,          movie.voteAverage.toFloat())
                        putString(ARG_RELEASE_DATE,   movie.releaseDate)
                        putString(ARG_OVERVIEW,       movie.overview)
                        putInt(ARG_RUNTIME,           movie.runtime ?: -1)
                    }
                    findNavController().navigate(R.id.movieDetailFragment, bundle)
                }
                binding.rvSimilar.adapter = similarAdapter
            }
        }
    }

    override fun onDestroyView() {
        // Prevent memory leaks by cleaning up the ad object reference
        startAppBanner = null
        bannerContainer = null
        _binding = null
        super.onDestroyView()
    }

    // ─── UI Binding ───────────────────────────────────────────────────────────

    private fun bindUI(movie: Movie) {
        binding.tvTitle.text    = movie.title
        binding.tvOverview.text = movie.overview
        binding.tvRating.text   = "⭐ ${movie.ratingFormatted}"
        binding.tvYear.text     = movie.releaseYear
        binding.tvRuntime.text  = movie.runtimeFormatted

        Glide.with(this)
            .load(movie.backdropUrl)
            .placeholder(R.drawable.placeholder_poster)
            .transition(DrawableTransitionOptions.withCrossFade())
            .centerCrop()
            .into(binding.ivBackdrop)

        Glide.with(this)
            .load(movie.posterUrl)
            .placeholder(R.drawable.placeholder_poster)
            .transition(DrawableTransitionOptions.withCrossFade())
            .centerCrop()
            .into(binding.ivPoster)

        binding.btnBack.setOnClickListener {
            findNavController().popBackStack()
        }

        updateActionButtons(movie)
    }

    private fun updateActionButtons(movie: Movie) {
        val hasRuntime = movie.runtime != null && movie.runtime!! > 0

        if (hasRuntime) {
            binding.btnPlay.isEnabled = true
            binding.btnPlay.text      = "▶ Play"
            binding.btnPlay.backgroundTintList =
                android.content.res.ColorStateList.valueOf(
                    android.graphics.Color.parseColor("#1E88E5")
                )
            binding.btnPlay.setOnClickListener { onPlayClicked() }

            binding.btnDownload.isEnabled = true
            binding.btnDownload.text      = "📥 Download"
            binding.btnDownload.backgroundTintList =
                android.content.res.ColorStateList.valueOf(
                    android.graphics.Color.parseColor("#1E88E5")
                )
            binding.btnDownload.setOnClickListener { onDownloadClicked() }

        } else {
            binding.btnPlay.isEnabled = false
            binding.btnPlay.text      = "🕐 Not Available"
            binding.btnPlay.backgroundTintList =
                android.content.res.ColorStateList.valueOf(
                    android.graphics.Color.parseColor("#444466")
                )

            binding.btnDownload.isEnabled = false
            binding.btnDownload.text      = "🕐 Not Available"
            binding.btnDownload.backgroundTintList =
                android.content.res.ColorStateList.valueOf(
                    android.graphics.Color.parseColor("#444466")
                )
        }
    }

    private fun checkDownloadState(movieId: Int) {
        lifecycleScope.launch {
            val isDownloaded = db.offlineMovieDao().isMovieDownloaded(movieId)
            val isActive     = DownloadService.activeDownloads.contains(movieId)
            if (_binding == null) return@launch
            when {
                isDownloaded -> {
                    binding.btnDownload.text = "✓ Saved"
                    binding.btnDownload.isEnabled = false
                    binding.btnDownload.backgroundTintList =
                        android.content.res.ColorStateList.valueOf(
                            android.graphics.Color.parseColor("#43A047")
                        )
                }
                isActive -> {
                    binding.btnDownload.text = "Downloading…"
                    binding.btnDownload.isEnabled = false
                    binding.btnDownload.backgroundTintList =
                        android.content.res.ColorStateList.valueOf(
                            android.graphics.Color.parseColor("#FB8C00")
                        )
                }
                else -> {
                    binding.btnDownload.text = "📥 Download"
                    binding.btnDownload.isEnabled = true
                }
            }
        }
    }

    private fun fetchFullDetail(movieId: Int) {
        lifecycleScope.launch {
            val result = repo.getMovieDetail(movieId)
            result.onSuccess { detail ->
                if (_binding == null) return@onSuccess

                binding.tvRuntime.text = detail.runtime?.let { "⏳ $it mins" } ?: "⏳ --"

                val genres = detail.genres.joinToString("  •  ") { it.name }
                binding.tvGenres.text = genres

                currentMovie = currentMovie?.copy(runtime = detail.runtime)
                currentMovie?.let { updateActionButtons(it) }
            }
        }
    }

    private fun onPlayClicked() {
        val movie = currentMovie ?: return
        binding.btnPlay.isEnabled = false
        binding.btnPlay.text = "🔍 Loading…"

        StreamScraper.resolve(requireContext(), movie.id) { streamUrl ->
            if (_binding == null) return@resolve
            binding.btnPlay.isEnabled = true
            binding.btnPlay.text = "▶ Play"

            if (streamUrl == null) {
                Toast.makeText(requireContext(), "❌ Stream not found", Toast.LENGTH_LONG).show()
                return@resolve
            }

            val intent = Intent(requireContext(), PlayerActivity::class.java).apply {
                putExtra(PlayerActivity.EXTRA_STREAM_URL,      streamUrl)
                putExtra(PlayerActivity.EXTRA_MOVIE_TITLE,     movie.title)
                putExtra(PlayerActivity.EXTRA_MOVIE_ID,        movie.id)
                putExtra("poster_path",                        movie.posterPath)
                putExtra(PlayerActivity.EXTRA_BACKDROP_PATH,   movie.backdropPath)
                putExtra(PlayerActivity.EXTRA_VOTE_AVERAGE,    movie.voteAverage)
                putExtra(PlayerActivity.EXTRA_RELEASE_DATE_STR, movie.releaseDate)
                putExtra(PlayerActivity.EXTRA_OVERVIEW,        movie.overview)
                movie.runtime?.let { putExtra(PlayerActivity.EXTRA_RUNTIME, it) }
            }
            startActivity(intent)
        }
    }
    private fun onDownloadClicked() {
        val movie = currentMovie ?: return
        binding.btnDownload.isEnabled = false
        binding.btnDownload.text = "🔍 Resolving…"

        StreamScraper.resolve(requireContext(), movie.id) { streamUrl ->
            if (_binding == null) return@resolve
            if (streamUrl == null) {
                Toast.makeText(requireContext(), "❌ Stream not found", Toast.LENGTH_LONG).show()
                binding.btnDownload.isEnabled = true
                binding.btnDownload.text = "📥 Download"
                return@resolve
            }

            val intent = Intent(requireContext(), DownloadService::class.java).apply {
                action = DownloadService.ACTION_START_DOWNLOAD
                putExtra(DownloadService.EXTRA_MOVIE_ID,     movie.id)
                putExtra(DownloadService.EXTRA_MOVIE_TITLE,  movie.title)
                putExtra(DownloadService.EXTRA_POSTER_PATH,  movie.posterPath)
                putExtra(DownloadService.EXTRA_VOTE_AVERAGE, movie.voteAverage)
                putExtra(DownloadService.EXTRA_RELEASE_DATE, movie.releaseDate)
                movie.runtime?.let { putExtra(DownloadService.EXTRA_RUNTIME, it) }
                putExtra(DownloadService.EXTRA_STREAM_URL,   streamUrl)
            }
            requireContext().startService(intent)

            binding.btnDownload.text = "Downloading…"
            binding.btnDownload.backgroundTintList =
                android.content.res.ColorStateList.valueOf(
                    android.graphics.Color.parseColor("#FB8C00")
                )
        }
    }
}