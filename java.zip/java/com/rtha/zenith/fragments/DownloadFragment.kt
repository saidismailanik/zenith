package com.rtha.zenith.fragments

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.LinearLayoutManager
import com.rtha.zenith.R
import com.rtha.zenith.activities.PlayerActivity
import com.rtha.zenith.adapters.MovieAdapter
import com.rtha.zenith.databinding.FragmentDownloadBinding
import com.rtha.zenith.models.AppDatabase
import com.rtha.zenith.models.Movie
import com.rtha.zenith.services.DownloadService
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File

class DownloadFragment : Fragment() {

    private var _binding: FragmentDownloadBinding? = null
    private val binding get() = _binding!!

    private lateinit var movieAdapter: MovieAdapter
    private lateinit var db: AppDatabase
    private lateinit var broadcaster: LocalBroadcastManager
    private var exoPlayer: ExoPlayer? = null
    private var pendingVideoPath: String? = null

    // Seek state
    private var pendingSeekLeft  = 0
    private var pendingSeekRight = 0
    private val seekResetHandler = Handler(Looper.getMainLooper())
    private val resetLeftRunnable  = Runnable { pendingSeekLeft  = 0 }
    private val resetRightRunnable = Runnable { pendingSeekRight = 0 }

    companion object {
        const val SEEK_INCREMENT_MS = 10_000L
    }

    private val downloadCompleteReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == DownloadService.ACTION_DOWNLOAD_COMPLETE) {
                loadDownloadedMovies()
            }
        }
    }

    // ─── Lifecycle ────────────────────────────────────────────────────────────

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDownloadBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        db = AppDatabase.getInstance(requireContext())
        broadcaster = LocalBroadcastManager.getInstance(requireContext())
        setupRecyclerView()
        loadDownloadedMovies()
        broadcaster.registerReceiver(
            downloadCompleteReceiver,
            IntentFilter(DownloadService.ACTION_DOWNLOAD_COMPLETE)
        )
    }

    override fun onResume() {
        super.onResume()
        exoPlayer?.play()
        if (exoPlayer == null && pendingVideoPath != null) {
            val file = File(pendingVideoPath!!)
            if (file.exists()) startPlayback(file)
        }
    }

    override fun onPause() {
        exoPlayer?.pause()
        super.onPause()
    }

    override fun onDestroyView() {
        releasePlayer()
        seekResetHandler.removeCallbacksAndMessages(null)
        broadcaster.unregisterReceiver(downloadCompleteReceiver)
        _binding = null
        super.onDestroyView()
    }

    // ─── RecyclerView ─────────────────────────────────────────────────────────

    private fun setupRecyclerView() {
        movieAdapter = MovieAdapter(
            mode = MovieAdapter.Mode.DOWNLOADS,
            onDeleteClick = ::confirmDelete,
            onCardClick = ::playMovie
        )
        binding.rvDownloads.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = movieAdapter
        }
    }

    private fun loadDownloadedMovies() {
        lifecycleScope.launch {
            db.offlineMovieDao().getAllMovies().collectLatest { entities ->
                if (_binding == null) return@collectLatest
                val movies = entities.map { it.toOfflineMovie().toMovie() }
                movieAdapter.submitList(movies)
                binding.tvEmpty.visibility = if (movies.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    // ─── Playback ─────────────────────────────────────────────────────────────

    private fun playMovie(movie: Movie) {
        lifecycleScope.launch {
            val entity = db.offlineMovieDao().getMovieById(movie.id) ?: return@launch
            val videoFile = File(entity.localFilePath)
            if (!videoFile.exists()) {
                Toast.makeText(requireContext(), "File not found", Toast.LENGTH_SHORT).show()
                return@launch
            }
            pendingVideoPath = videoFile.absolutePath
            startPlayback(videoFile)
        }
    }

    private fun startPlayback(videoFile: File) {
        if (_binding == null) return

        binding.playerContainer.visibility = View.VISIBLE
        binding.playerView.requestFocus()

        releasePlayer()

        exoPlayer = ExoPlayer.Builder(requireContext()).build().also { player ->
            binding.playerView.player = player
            player.setMediaItem(MediaItem.fromUri(Uri.fromFile(videoFile)))
            player.prepare()
            player.playWhenReady = true
            player.addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    if (_binding == null) return
                    Toast.makeText(
                        requireContext(),
                        "Playback error: ${error.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        }

        setupDoubleTap()

        binding.playerView.postDelayed({
            binding.playerView.findViewById<ImageButton>(R.id.btnClosePlayer)
                ?.setOnClickListener {
                    releasePlayer()
                    binding.playerContainer.visibility = View.GONE
                    pendingVideoPath = null
                }
        }, 500)

        binding.btnFullscreen.setOnClickListener {
            val currentPosition = exoPlayer?.currentPosition ?: 0L
            val intent = Intent(requireContext(), PlayerActivity::class.java).apply {
                putExtra(
                    PlayerActivity.EXTRA_STREAM_URL,
                    Uri.fromFile(File(pendingVideoPath!!)).toString()
                )
                putExtra("seek_position", currentPosition)
            }
            startActivity(intent)
        }
    }

    private fun releasePlayer() {
        exoPlayer?.release()
        exoPlayer = null
    }

    // ─── Double Tap Seek ──────────────────────────────────────────────────────

    private fun setupDoubleTap() {
        if (_binding == null) return

        val playerView = binding.playerView
        val leftView   = binding.doubleTapLeft
        val rightView  = binding.doubleTapRight

        var leftDoubleTapped  = false
        var rightDoubleTapped = false

        val leftGesture = GestureDetector(requireContext(),
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onDoubleTap(e: MotionEvent): Boolean {
                    leftDoubleTapped = true
                    seekBackward()
                    return true
                }
            })

        val rightGesture = GestureDetector(requireContext(),
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onDoubleTap(e: MotionEvent): Boolean {
                    rightDoubleTapped = true
                    seekForward()
                    return true
                }
            })

        leftView.setOnTouchListener { _, event ->
            leftGesture.onTouchEvent(event)
            when (event.action) {
                MotionEvent.ACTION_DOWN -> leftDoubleTapped = false
                MotionEvent.ACTION_UP -> {
                    if (!leftDoubleTapped) {
                        val down = MotionEvent.obtain(event).apply {
                            action = MotionEvent.ACTION_DOWN
                        }
                        playerView.dispatchTouchEvent(down)
                        playerView.dispatchTouchEvent(event)
                        down.recycle()
                    }
                    leftDoubleTapped = false
                }
            }
            true
        }

        rightView.setOnTouchListener { _, event ->
            rightGesture.onTouchEvent(event)
            when (event.action) {
                MotionEvent.ACTION_DOWN -> rightDoubleTapped = false
                MotionEvent.ACTION_UP -> {
                    if (!rightDoubleTapped) {
                        val down = MotionEvent.obtain(event).apply {
                            action = MotionEvent.ACTION_DOWN
                        }
                        playerView.dispatchTouchEvent(down)
                        playerView.dispatchTouchEvent(event)
                        down.recycle()
                    }
                    rightDoubleTapped = false
                }
            }
            true
        }
    }

    private fun seekForward() {
        val player = exoPlayer ?: return
        pendingSeekRight += 10
        seekResetHandler.removeCallbacks(resetRightRunnable)
        seekResetHandler.postDelayed(resetRightRunnable, 1000)
        player.seekTo(
            (player.currentPosition + SEEK_INCREMENT_MS).coerceAtMost(player.duration)
        )
        if (_binding == null) return
        binding.tvSeekRight.text = "▶▶ ${pendingSeekRight}s"
        showSeekOverlay(binding.tvSeekRight)
        binding.playerView.hideController()
    }

    private fun seekBackward() {
        val player = exoPlayer ?: return
        pendingSeekLeft += 10
        seekResetHandler.removeCallbacks(resetLeftRunnable)
        seekResetHandler.postDelayed(resetLeftRunnable, 1000)
        player.seekTo(
            (player.currentPosition - SEEK_INCREMENT_MS).coerceAtLeast(0L)
        )
        if (_binding == null) return
        binding.tvSeekLeft.text = "◀◀ ${pendingSeekLeft}s"
        showSeekOverlay(binding.tvSeekLeft)
        binding.playerView.hideController()
    }

    private fun showSeekOverlay(view: TextView) {
        view.clearAnimation()
        view.alpha = 1f
        view.visibility = View.VISIBLE
        view.animate()
            .setStartDelay(600)
            .setDuration(400)
            .alpha(0f)
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    view.visibility = View.GONE
                    view.alpha = 1f
                }
            })
    }

    // ─── Delete ───────────────────────────────────────────────────────────────

    private fun confirmDelete(movie: Movie) {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete Download")
            .setMessage("Remove \"${movie.title}\" from your downloads?")
            .setPositiveButton("🗑 Delete") { _, _ -> deleteMovie(movie) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteMovie(movie: Movie) {
        lifecycleScope.launch {
            val entity = db.offlineMovieDao().getMovieById(movie.id) ?: return@launch
            if (exoPlayer?.isPlaying == true) {
                releasePlayer()
                if (_binding != null) binding.playerContainer.visibility = View.GONE
            }
            File(entity.localFilePath).takeIf { it.exists() }?.delete()
            db.offlineMovieDao().deleteMovieById(movie.id)
            Toast.makeText(requireContext(), "Deleted", Toast.LENGTH_SHORT).show()
        }
    }
}