package com.rtha.zenith.network

import com.rtha.zenith.BuildConfig
import com.rtha.zenith.models.CreditsResponse
import com.rtha.zenith.models.ExternalIds
import com.rtha.zenith.models.GenreResponse
import com.rtha.zenith.models.MovieDetail
import com.rtha.zenith.models.MovieResponse
import com.rtha.zenith.models.Genre
import com.rtha.zenith.models.Movie
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// ─── API Interface ────────────────────────────────────────────────────────────

interface TmdbApiService {

    @GET("movie/{movie_id}/credits")
    suspend fun getMovieCredits(
        @Path("movie_id") movieId: Int,
        @Query("api_key") apiKey: String
    ): Response<CreditsResponse>

    @GET("movie/{movie_id}/similar")
    suspend fun getSimilarMovies(
        @Path("movie_id") movieId: Int,
        @Query("api_key") apiKey: String,
        @Query("page") page: Int = 1
    ): Response<MovieResponse>
    @GET("movie/popular")
    suspend fun getPopularMovies(
        @Query("api_key") apiKey: String,
        @Query("page") page: Int = 1
    ): Response<MovieResponse>

    @GET("movie/top_rated")
    suspend fun getTopRatedMovies(
        @Query("api_key") apiKey: String,
        @Query("page") page: Int = 1
    ): Response<MovieResponse>

    @GET("discover/movie")
    suspend fun getMoviesByGenre(
        @Query("api_key") apiKey: String,
        @Query("with_genres") genreId: Int,
        @Query("page") page: Int = 1,
        @Query("sort_by") sortBy: String = "popularity.desc"
    ): Response<MovieResponse>

    @GET("search/movie")
    suspend fun searchMovies(
        @Query("api_key") apiKey: String,
        @Query("query") query: String,
        @Query("page") page: Int = 1
    ): Response<MovieResponse>

    @GET("movie/{movie_id}")
    suspend fun getMovieDetail(
        @Path("movie_id") movieId: Int,
        @Query("api_key") apiKey: String
    ): Response<MovieDetail>

    @GET("genre/movie/list")
    suspend fun getGenres(
        @Query("api_key") apiKey: String
    ): Response<GenreResponse>

    @GET("movie/{movie_id}/external_ids")
    suspend fun getExternalIds(
        @Path("movie_id") movieId: Int,
        @Query("api_key") apiKey: String
    ): Response<ExternalIds>
}

// ─── Retrofit Client ──────────────────────────────────────────────────────────

object RetrofitClient {

    private const val BASE_URL = "https://api.themoviedb.org/3/"
    private const val CONNECT_TIMEOUT = 5L
    private const val READ_TIMEOUT = 5L

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(CONNECT_TIMEOUT, TimeUnit.SECONDS)
        .readTimeout(READ_TIMEOUT, TimeUnit.SECONDS)
        .writeTimeout(CONNECT_TIMEOUT, TimeUnit.SECONDS)
        .addInterceptor(loggingInterceptor)
        .retryOnConnectionFailure(true)
        .build()

    val apiService: TmdbApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(TmdbApiService::class.java)
    }
}

// ─── Repository ───────────────────────────────────────────────────────────────

class MovieRepository {

    private val api = RetrofitClient.apiService
    private val apiKey = com.rtha.zenith.BuildConfig.TMDB_API_KEY

    suspend fun getImdbId(movieId: Int): String? {
        return try {
            val response = api.getExternalIds(movieId, apiKey)
            response.body()?.imdbId
        } catch (e: Exception) { null }
    }
    suspend fun getPopularMovies(page: Int = 1): Result<List<com.rtha.zenith.models.Movie>> {
        return try {
            val response = api.getPopularMovies(apiKey, page)
            if (response.isSuccessful) {
                Result.success(response.body()?.results ?: emptyList())
            } else {
                Result.failure(Exception("API error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getMoviesByGenre(genreId: Int, page: Int = 1): Result<List<com.rtha.zenith.models.Movie>> {
        return try {
            val response = api.getMoviesByGenre(apiKey, genreId, page)
            if (response.isSuccessful) {
                Result.success(response.body()?.results ?: emptyList())
            } else {
                Result.failure(Exception("API error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun searchMovies(query: String, page: Int = 1): Result<List<com.rtha.zenith.models.Movie>> {
        return try {
            val response = api.searchMovies(apiKey, query, page)
            if (response.isSuccessful) {
                Result.success(response.body()?.results ?: emptyList())
            } else {
                Result.failure(Exception("API error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getMovieDetail(movieId: Int): Result<com.rtha.zenith.models.MovieDetail> {
        return try {
            val response = api.getMovieDetail(movieId, apiKey)
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                Result.failure(Exception("API error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getMovieCredits(movieId: Int): Result<com.rtha.zenith.models.CreditsResponse> {
        return try {
            val response = api.getMovieCredits(movieId, apiKey)
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                Result.failure(Exception("API error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getSimilarMovies(movieId: Int): Result<List<com.rtha.zenith.models.Movie>> {
        return try {
            val response = api.getSimilarMovies(movieId, apiKey)
            if (response.isSuccessful) {
                Result.success(response.body()?.results ?: emptyList())
            } else {
                Result.failure(Exception("API error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}